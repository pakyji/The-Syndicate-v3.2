const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ensureSupportPanel } = require('../handlers/supportSystem');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('lfg-setup')
        .setDescription('Deploys the interactive LFG and Support desk panel')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator), // Sirf admins ke liye (optional)
    async execute(interaction) {
        try {
            await interaction.deferReply({ ephemeral: true });
            
            // Support panel function ko call karein jo handlers/supportSystem.js mein hai
            await ensureSupportPanel(interaction.client);

            await interaction.editReply({
                content: '✅ **LFG & Support Panel** has been successfully deployed/verified in the designated channels!'
            });
        } catch (error) {
            console.error('Error executing lfg-setup:', error);
            if (interaction.deferred || interaction.replied) {
                await interaction.editReply({ content: '❌ Failed to deploy the support panel.' }).catch(() => {});
            } else {
                await interaction.reply({ content: '❌ Failed to deploy the support panel.', ephemeral: true }).catch(() => {});
            }
        }
    }
};