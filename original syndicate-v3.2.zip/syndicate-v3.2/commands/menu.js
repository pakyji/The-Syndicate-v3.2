// ═══════════════════════════════════════════════
//              THE SYNDICATE V 3.2
//         ULTIMATE DYNAMIC AUTO-LOADING MENU
// ═══════════════════════════════════════════════
// Developed & Maintained by The Syndicate Staff Team
// Automatically reads and displays all available commands
// ═══════════════════════════════════════════════

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const data = new SlashCommandBuilder()
    .setName('menu')
    .setDescription('Displays the complete list of all active bot commands automatically');

module.exports = {
    data,
    async execute(target, isPrefix) {
        // Prevent Discord interaction timeout (3-second rule)
        try {
            if (!target.deferred && !target.replied) {
                if (typeof target.deferReply === 'function') {
                    await target.deferReply().catch(() => {});
                }
            }
        } catch (e) {
            // Safe catch for prefix or non-interaction targets
        }

        // Ultimate Recursive function to deep-scan all directories and sub-folders
        const getAllJsFiles = (dir) => {
            let results = [];
            try {
                if (!fs.existsSync(dir)) return results;
                const list = fs.readdirSync(dir);
                list.forEach(file => {
                    const filePath = path.join(dir, file);
                    const stat = fs.statSync(filePath);
                    if (stat && stat.isDirectory()) {
                        results = results.concat(getAllJsFiles(filePath));
                    } else if (file.endsWith('.js')) {
                        results.push(filePath);
                    }
                });
            } catch (err) {
                console.error(`Error scanning directory ${dir}:`, err);
            }
            return results;
        };

        // Target the root project directory so it scans everything automatically
        const rootDir = path.join(__dirname, '../');
        let commandLines = [];
        const registeredCommands = new Set(); // Prevent duplicate commands

        try {
            const allFiles = getAllJsFiles(rootDir);
            for (const filePath of allFiles) {
                try {
                    // Skip menu.js itself to avoid listing menu twice
                    if (filePath.includes('menu.js')) continue;

                    // Clear require cache to ensure fresh command data is loaded
                    delete require.cache[require.resolve(filePath)];
                    const command = require(filePath);
                    
                    if (command && command.data && command.data.name && command.data.description) {
                        const cmdName = command.data.name;
                        if (!registeredCommands.has(cmdName)) {
                            registeredCommands.add(cmdName);
                            commandLines.push(`• **/${cmdName}** - ${command.data.description}`);
                        }
                    }
                } catch (err) {
                    // Skip non-command or faulty files safely without crashing
                }
            }
        } catch (error) {
            console.error('Failed to load command directories:', error);
        }

        // Sort commands alphabetically for neat organization
        commandLines.sort();

        // Build the dynamic menu embed with Platform at the top of description
        const menuEmbed = new EmbedBuilder()
            .setTitle('⚜ THE SYNDICATE V3.2 — ULTIMATE DYNAMIC MENU ⚜')
            .setDescription('* Platform : Ubuntu / Linux\n\nHere is the complete list of all active modules and commands dynamically loaded from the system.')
            .setColor('#2b2d31')
            .setImage('https://i.imgur.com/Ie4j48r.jpeg')
            .setFooter({ text: 'Powered by The Syndicate Staff Team • The Syndicate Core - made by ❤️ | Today' })
            .setTimestamp();

        // Safely split commands into chunks to avoid the 1024 character limit per field error
        if (commandLines.length > 0) {
            let currentFieldVal = '';
            let fieldCount = 1;

            for (const line of commandLines) {
                // Check if adding this line exceeds 1024 characters
                if ((currentFieldVal + line + '\n').length > 1024) {
                    menuEmbed.addFields({ 
                        name: fieldCount === 1 ? '🛡️ Active Modules & Commands' : `🛡️ Active Modules & Commands (Cont. ${fieldCount})`, 
                        value: currentFieldVal, 
                        inline: false 
                    });
                    currentFieldVal = '';
                    fieldCount++;
                }
                currentFieldVal += line + '\n';
            }

            // Add the remaining commands
            if (currentFieldVal.trim() !== '') {
                menuEmbed.addFields({ 
                    name: fieldCount === 1 ? '🛡️ Active Modules & Commands' : `🛡️ Active Modules & Commands (Cont. ${fieldCount})`, 
                    value: currentFieldVal, 
                    inline: false 
                });
            }
        } else {
            menuEmbed.addFields({ 
                name: '🛡️ Active Modules & Commands', 
                value: 'No commands found.', 
                inline: false 
            });
        }

        // Safe reply mechanism to ensure no error is thrown
        try {
            if (isPrefix && typeof target.reply === 'function' && !target.deferred) {
                await target.reply({ embeds: [menuEmbed] });
            } else if (target.editReply) {
                await target.editReply({ embeds: [menuEmbed] });
            } else if (target.reply) {
                await target.reply({ embeds: [menuEmbed] });
            }
        } catch (err) {
            console.error('Error sending menu response:', err);
        }
    }
};