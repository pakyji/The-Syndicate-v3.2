const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('poll')
        .setDescription('Create an interactive poll for the server.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addStringOption(option => 
            option.setName('question')
            .setDescription('The question you want to ask in the poll')
            .setRequired(true)
        )
        .addStringOption(option => 
            option.setName('option1')
            .setDescription('First option')
            .setRequired(true)
        )
        .addStringOption(option => 
            option.setName('option2')
            .setDescription('Second option')
            .setRequired(true)
        )
        .addStringOption(option => 
            option.setName('option3')
            .setDescription('Third option (optional)')
            .setRequired(false)
        )
        .addStringOption(option => 
            option.setName('option4')
            .setDescription('Fourth option (optional)')
            .setRequired(false)
        )
        .addStringOption(option => 
            option.setName('option5')
            .setDescription('Fifth option (optional)')
            .setRequired(false)
        )
        .addIntegerOption(option =>
            option.setName('duration')
            .setDescription('Poll duration (Default is 24 Hours)')
            .setRequired(false)
            .addChoices(
                { name: '1 Hour', value: 1 },
                { name: '4 Hours', value: 4 },
                { name: '8 Hours', value: 8 },
                { name: '24 Hours (1 Day)', value: 24 },
                { name: '72 Hours (3 Days)', value: 72 },
                { name: '168 Hours (1 Week)', value: 168 }
            )
        )
        .addBooleanOption(option => 
            option.setName('multiselect')
            .setDescription('Allow members to select multiple answers? (Default: False)')
            .setRequired(false)
        ),

    async execute(interaction) {
        const question = interaction.options.getString('question');
        const duration = interaction.options.getInteger('duration') || 24;
        const multiselect = interaction.options.getBoolean('multiselect') ?? false;

        const rawOptions = [
            interaction.options.getString('option1'),
            interaction.options.getString('option2'),
            interaction.options.getString('option3'),
            interaction.options.getString('option4'),
            interaction.options.getString('option5')
        ];

        const answers = rawOptions
            .filter(opt => opt !== null && opt.trim() !== '')
            .map(opt => ({ text: opt }));

        try {
            await interaction.reply({
                poll: {
                    question: { text: question },
                    answers: answers,
                    allowMultiselect: multiselect,
                    duration: duration,
                }
            });
        } catch (error) {
            console.error('❌ Poll generation error:', error);
            
            await interaction.reply({ 
                content: '❌ Failed to create the poll. (Make sure you are using Discord.js v14.15+)', 
                ephemeral: true 
            });
        }
    }
};