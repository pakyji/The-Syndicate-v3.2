const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Clears a specific number of messages or deletes recent messages.')
        .addStringOption(option =>
            option.setName('amount')
                .setDescription('Enter a number (e.g. 200) or type "all"')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        // Ephemeral reply taaki command ka output sirf admin/mod ko dikhe
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const input = interaction.options.getString('amount').trim().toLowerCase();
        const channel = interaction.channel;

        let targetCount = 0;

        if (input === 'all') {
            targetCount = 500; // Ek safe limit tak messages fetch karke delete karega
        } else {
            targetCount = parseInt(input);
            if (isNaN(targetCount) || targetCount <= 0) {
                return interaction.editReply({ content: '❌ Please enter a valid positive number or "all".' });
            }
        }

        let totalDeleted = 0;

        try {
            while (targetCount > 0) {
                const fetchLimit = targetCount > 100 ? 100 : targetCount;
                const messages = await channel.messages.fetch({ limit: fetchLimit });

                if (messages.size === 0) break;

                // Bulk delete messages (true flag skips messages older than 14 days automatically to avoid errors)
                const deleted = await channel.bulkDelete(messages, true).catch(() => null);
                
                if (!deleted || deleted.size === 0) break;

                totalDeleted += deleted.size;
                targetCount -= deleted.size;

                // Agar channel mein aur messages nahi bache toh loop roq do
                if (messages.size < fetchLimit) break;
            }

            return interaction.editReply({
                content: `✅ Successfully cleared **${totalDeleted}** messages! *(Note: Messages older than 14 days cannot be bulk deleted due to Discord limitations)*`
            });

        } catch (error) {
            console.error('Clear command error:', error);
            return interaction.editReply({ content: '❌ An error occurred while trying to clear messages in this channel.' });
        }
    },
};