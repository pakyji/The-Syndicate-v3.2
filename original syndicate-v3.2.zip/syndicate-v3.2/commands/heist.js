const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

// All target channel IDs where the LFG alert must be sent simultaneously
const CHANNELS = {
    GENERAL: '901685831943733268',
    GTA_SUPPORT: '1535656533919014932',
    ITALIAN: '1537221793922940928'
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('heist')
        .setDescription('Organize a heist crew with precise platform separation and missions!')
        .addStringOption(option =>
            option.setName('mission')
                .setDescription('Select the heist or robbery mission')
                .setRequired(true)
                .addChoices(
                    { name: 'Cayo Perico Heist', value: 'Cayo Perico Heist' },
                    { name: 'Diamond Casino Heist', value: 'Diamond Casino Heist' },
                    { name: 'Doomsday Heist', value: 'Doomsday Heist' },
                    { name: 'Salvage Yard Robberies (The Chop Shop)', value: 'Salvage Yard Robberies' },
                    { name: 'Pacific Standard', value: 'Pacific Standard' },
                    { name: 'Classic Setup / Mission', value: 'Classic Setup' }
                )
        )
        .addIntegerOption(option =>
            option.setName('players')
                .setDescription('Number of crew members needed')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(3)
        )
        .addStringOption(option =>
            option.setName('platform')
                .setDescription('Select your exact gaming platform')
                .setRequired(true)
                .addChoices(
                    { name: 'PC', value: 'PC' },
                    { name: 'PC Enhanced', value: 'PC Enhanced' },
                    { name: 'PlayStation 4 (PS4)', value: 'PlayStation 4' },
                    { name: 'PlayStation 5 (PS5)', value: 'PlayStation 5' },
                    { name: 'Xbox One', value: 'Xbox One' },
                    { name: 'Xbox Series X|S', value: 'Xbox Series X|S' }
                )
        )
        .addStringOption(option =>
            option.setName('requirements')
                .setDescription('Host requirements / notes (e.g. Mic required, Level 100+)')
                .setRequired(false)
        ),

    async execute(interaction, isMessageCommand) {
        const mission = interaction.options.getString('mission');
        const neededPlayers = interaction.options.getInteger('players');
        const platform = interaction.options.getString('platform');
        const requirements = interaction.options.getString('requirements') || 'No special requirements. Come prepared!';
        const host = interaction.user;

        // Private acknowledgment so the command doesn't timeout
        await interaction.reply({
            content: '🚀 Broadcasting high-priority LFG alerts across all Syndicate channels...',
            flags: [MessageFlags.Ephemeral]
        });

        // Loop through all specified channels and dispatch respective localized alerts
        for (const [key, channelId] of Object.entries(CHANNELS)) {
            const channel = await interaction.client.channels.fetch(channelId).catch(() => null);
            if (!channel) continue;

            let embed, alertContent, btnLabel;
            const isItalianChannel = (channelId === CHANNELS.ITALIAN);

            if (isItalianChannel) {
                // Italian Language & Guide for the Italian Channel
                alertContent = `📢 **Allarme LFG ad alta priorità!** Una nuova squadra per il colpo si sta radunando!`;
                btnLabel = `Unisciti alla Crew`;
                
                embed = new EmbedBuilder()
                    .setTitle('🚨 SPEDIZIONE COLPO LOS SANTOS — ALLARME LFG')
                    .setDescription(`**Guida / Come partecipare:**\n1. Clicca sul pulsante **"Unisciti alla Crew"** qui sotto.\n2. Assicurati di essere pronto su GTA Online.\n3. Contatta il capo squadra per i dettagli dell'invito.\n\n**${host}** sta mettendo su una squadra d'élite per un'operazione importante!`)
                    .setColor('#2b2d31')
                    .addFields(
                        { name: '🎯 Missione', value: `\`${mission}\``, inline: true },
                        { name: '🖥️ Piattaforma', value: `\`${platform}\``, inline: true },
                        { name: '👥 Posti Liberi', value: `\`${neededPlayers} Giocatore/i\``, inline: true },
                        { name: '📋 Requisiti del Host', value: `\`${requirements}\``, inline: false },
                        { name: '👤 Capo Squadra', value: `${host}`, inline: false }
                    )
                    .setImage('https://i.imgur.com/Ie4j48r.jpeg')
                    .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ♥️' })
                    .setTimestamp();
            } else {
                // English Language & Guide for General / Support Channels
                alertContent = `📢 **High-Priority LFG Alert!** A new heist crew is assembling!`;
                btnLabel = `Join Crew`;

                embed = new EmbedBuilder()
                    .setTitle('🚨 LOS SANTOS HEIST DISPATCH — LFG ALERT')
                    .setDescription(`**Guide / How to join:**\n1. Click the **"Join Crew"** button below.\n2. Ensure you are online and ready in GTA Online.\n3. Reach out to the heist leader for invites.\n\n**${host}** is putting together a high-stakes crew for a major operation!`)
                    .setColor('#2b2d31')
                    .addFields(
                        { name: '🎯 Target Mission', value: `\`${mission}\``, inline: true },
                        { name: '🖥️ Platform', value: `\`${platform}\``, inline: true },
                        { name: '👥 Slots Needed', value: `\`${neededPlayers} Player(s)\``, inline: true },
                        { name: '📋 Host Requirements', value: `\`${requirements}\``, inline: false },
                        { name: '👤 Heist Leader', value: `${host}`, inline: false }
                    )
                    .setImage('https://i.imgur.com/Ie4j48r.jpeg')
                    .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ♥️' })
                    .setTimestamp();
            }

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('heist_join')
                    .setLabel(btnLabel)
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('🔫')
            );

            // Send message to this specific channel
            await channel.send({
                content: alertContent,
                embeds: [embed],
                components: [row]
            }).catch(err => console.error(`Failed to send to channel ${channelId}:`, err));
        }

        // Final confirmation to the command author
        await interaction.editReply({
            content: '✅ High-priority LFG heist alerts successfully broadcasted with updated platforms and missions!'
        });
    },
};