const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

// All target channel IDs for simultaneous broadcast
const CHANNELS = {
    GENERAL: '901685831943733268',
    GTA_SUPPORT: '1535656533919014932',
    ITALIAN: '1537221793922940928'
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('carmeet')
        .setDescription('Organize a Los Santos Car Meet and broadcast an alert across channels!')
        .addStringOption(option =>
            option.setName('location')
                .setDescription('Select the car meet location')
                .setRequired(true)
                .addChoices(
                    { name: 'LS Car Meet (Warehouse)', value: 'LS Car Meet Warehouse' },
                    { name: 'Vinewood Casino Parking', value: 'Vinewood Casino Parking' },
                    { name: 'Del Perro Pier', value: 'Del Perro Pier' },
                    { name: 'Airport Runway (LSIA)', value: 'LSIA Runway' },
                    { name: 'Mount Chiliad Lookout', value: 'Mount Chiliad Lookout' }
                )
        )
        .addStringOption(option =>
            option.setName('time')
                .setDescription('Timing or schedule (e.g., Tonight at 9 PM EST)')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('platform')
                .setDescription('Select your exact gaming platform')
                .setRequired(true)
                .addChoices(
                    { name: 'PC', value: 'PC' },
                    { name: 'PC Enhanced', value: 'PC Enhanced' },
                    { name: 'PlayStation 4 (PS4)', value: 'PlayStation 4' },
                    { name: 'PlayStation 5 (PS5)', value: 'PlayStation 5' },
                    { name: 'Xbox One', value: 'Xbox One' },
                    { name: 'Xbox Series X|S', value: 'Xbox Series X|S' }
                )
        )
        .addStringOption(option =>
            option.setName('theme')
                .setDescription('Car meet theme or dress code (e.g., JDM, Supercars, Tuners)')
                .setRequired(false)
        ),

    async execute(interaction, isMessageCommand) {
        const location = interaction.options.getString('location');
        const time = interaction.options.getString('time');
        const platform = interaction.options.getString('platform');
        const theme = interaction.options.getString('theme') || 'Any Vehicle / Open Class';
        const host = interaction.user;

        // Private acknowledgment
        await interaction.reply({
            content: '🚀 Broadcasting Car Meet notification across all Syndicate channels...',
            flags: [MessageFlags.Ephemeral]
        });

        // Loop through channels for broadcast
        for (const [key, channelId] of Object.entries(CHANNELS)) {
            const channel = await interaction.client.channels.fetch(channelId).catch(() => null);
            if (!channel) continue;

            let embed, alertContent, btnLabel;
            const isItalianChannel = (channelId === CHANNELS.ITALIAN);

            if (isItalianChannel) {
                // Italian Version for Italian Channel
                alertContent = `📢 **Raduno Auto ad alta priorità!** Preparate i vostri veicoli customizzati!`;
                btnLabel = `Partecipa al Meet`;

                embed = new EmbedBuilder()
                    .setTitle('🚗 RADUNO AUTO LOS SANTOS — CAR MEET')
                    .setDescription(`**Guida / Come partecipare:**\n1. Clicca sul pulsante **"Partecipa al Meet"** qui sotto.\n2. Modifica la tua auto secondo il tema stabilito.\n3. Entra nella sessione del host all'orario indicato.\n\n**${host}** sta organizzando un raduno epico per mostrare i ferri migliori di Los Santos!`)
                    .setColor('#2b2d31')
                    .addFields(
                        { name: '📍 Posizione', value: `\`${location}\``, inline: true },
                        { name: '⏰ Orario', value: `\`${time}\``, inline: true },
                        { name: '🖥️ Piattaforma', value: `\`${platform}\``, inline: true },
                        { name: '🎨 Tema / Stile', value: `\`${theme}\``, inline: false },
                        { name: '👤 Organizzatore', value: `${host}`, inline: false }
                    )
                    .setImage('https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80')
                    .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ♥️' })
                    .setTimestamp();
            } else {
                // English Version for General & Support Channels
                alertContent = `📢 **High-Priority Car Meet Alert!** Rev up your engines and polish your builds!`;
                btnLabel = `Join Car Meet`;

                embed = new EmbedBuilder()
                    .setTitle('🚗 LOS SANTOS CAR MEET — DISPATCH')
                    .setDescription(`**Guide / How to join:**\n1. Click the **"Join Car Meet"** button below.\n2. Get your vehicle ready according to the meet theme.\n3. Join the host session at the scheduled time.\n\n**${host}** is hosting an epic car meet to show off custom builds across Los Santos!`)
                    .setColor('#2b2d31')
                    .addFields(
                        { name: '📍 Location', value: `\`${location}\``, inline: true },
                        { name: '⏰ Schedule', value: `\`${time}\``, inline: true },
                        { name: '🖥️ Platform', value: `\`${platform}\``, inline: true },
                        { name: '🎨 Theme / Style', value: `\`${theme}\``, inline: false },
                        { name: '👤 Host', value: `${host}`, inline: false }
                    )
                    .setImage('https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80')
                    .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ♥️' })
                    .setTimestamp();
            }

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('carmeet_join')
                    .setLabel(btnLabel)
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('🏎️')
            );

            await channel.send({
                content: alertContent,
                embeds: [embed],
                components: [row]
            }).catch(err => console.error(`Failed to send carmeet to channel ${channelId}:`, err));
        }

        await interaction.editReply({
            content: '✅ Car Meet alert successfully broadcasted across all channels!'
        });
    },
};