const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

const aircraftThemes = [
    { category: 'Military Jets & Fighters', aircraft: 'P-996 LAZER / B-11 Strikeforce', image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=1200&q=80' },
    { category: 'Vtol Aircrafts', aircraft: 'Mammoth Hydra / F-160 Raiju', image: 'https://images.unsplash.com/photo-1519074069444-1ba4ea16d66c?auto=format&fit=crop&w=1200&q=80' },
    { category: 'Attack & Stealth Helicopters', aircraft: 'FH-1 Hunter / Akula / Annihilator Stealth', image: 'https://images.unsplash.com/photo-1508614589041-895b88991e3e?auto=format&fit=crop&w=1200&q=80' },
    { category: 'Heist Transport & Utility', aircraft: 'Valkyrie / Cargobob / Sparrow', image: 'https://images.unsplash.com/photo-1474302770737-173621bab9f7?auto=format&fit=crop&w=1200&q=80' },
    { category: 'Stunt & Private Planes', aircraft: 'Buckingham Luxor Deluxe / Mallard / Howard NX-25', image: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=1200&q=80' }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('airticker')
        .setDescription('Starts a live auto-updating aircraft ticker that changes every 5 seconds!'),

    async execute(interaction) {
        await interaction.reply({
            content: '✈️ Starting the fast 5-second live aircraft ticker...',
            flags: [MessageFlags.Ephemeral]
        });

        let currentIndex = 0;

        const generateEmbed = (index) => {
            const current = aircraftThemes[index];
            return new EmbedBuilder()
                .setTitle('🔄 LOS SANTOS LIVE AIRCRAFT TICKER')
                .setDescription(`*This display automatically updates every 5 seconds with military jets, helicopters, and airborne vehicles across Los Santos!*`)
                .setColor('#2b2d31')
                .addFields(
                    { name: '✈️ Air Category', value: `\`${current.category}\``, inline: true },
                    { name: '🚁 Featured Aircraft', value: `\`${current.aircraft}\``, inline: true },
                    { name: '⚡ Status', value: '`AIRSPACE TURBO LIVE`', inline: false }
                )
                .setImage(current.image)
                .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ♥️' })
                .setTimestamp();
        };

        const tickerMessage = await interaction.channel.send({
            embeds: [generateEmbed(currentIndex)]
        });

        const intervalId = setInterval(async () => {
            try {
                currentIndex = (currentIndex + 1) % aircraftThemes.length;
                await tickerMessage.edit({
                    embeds: [generateEmbed(currentIndex)]
                });
            } catch (error) {
                clearInterval(intervalId);
            }
        }, 5000); // 5 seconds
    },
};