const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

// Fixed Target Announcement Channel ID provided
const ANNOUNCEMENT_CHANNEL_ID = '1536261317051031622';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('announce')
        .setDescription('Send an official announcement to the designated announcement channel.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages) // Only admins/moderators can use it
        .addStringOption(option =>
            option.setName('message')
                .setDescription('The announcement message content')
                .setRequired(true)),

    async execute(interaction) {
        const announcementText = interaction.options.getString('message');

        // Fetch the target channel
        const targetChannel = await interaction.guild.channels.fetch(ANNOUNCEMENT_CHANNEL_ID).catch(() => null);

        if (!targetChannel || !targetChannel.isTextBased()) {
            return interaction.reply({ content: '❌ Announcement channel is not configured correctly or is not text-based!', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle('📢 THE SYNDICATE - Announcement')
            .setDescription(announcementText)
            .setColor('#e74c3c') // Attractive red accent
            .setImage('https://i.imgur.com/9nwxjf4.jpeg') // Banner image attached
            .setFooter({ text: 'Powered by The Syndicate Staff Team • The Syndicate Core - made by ❤️' })
            .setTimestamp();

        try {
            await targetChannel.send({ embeds: [embed] });
            await interaction.reply({ content: `✅ Announcement successfully sent to <#${ANNOUNCEMENT_CHANNEL_ID}>!`, ephemeral: true });
        } catch (error) {
            console.error('❌ Announcement Error:', error);
            await interaction.reply({ content: '❌ Failed to send the announcement. Check bot permissions!', ephemeral: true });
        }
    },
};