const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const LOG_CHANNEL_ID = '899366913086455828';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('purge')
        .setDescription('Delete a specified number of messages (1-100)')
        .addIntegerOption(option => option.setName('amount').setDescription('Number of messages to delete (1-100)').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const amount = interaction.options.getInteger('amount');

        if (amount < 1 || amount > 100) {
            return interaction.editReply({ content: '❌ Please specify a number between 1 and 100.' });
        }

        try {
            const deleted = await interaction.channel.bulkDelete(amount, true);

            const embed = new EmbedBuilder()
                .setColor('#00FFFF')
                .setTitle('🧹 Messages Purged')
                .setDescription(`Successfully deleted **${deleted.size}** messages in ${interaction.channel}.`)
                .addFields({ name: '🛡️ Moderator', value: `${interaction.user.tag}`, inline: true })
                .setTimestamp()
                .setFooter({ text: 'The Syndicate Staff Team' });

            await interaction.editReply({ embeds: [embed] });

            const logChannel = await interaction.guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
            if (logChannel) await logChannel.send({ embeds: [embed] }).catch(() => {});
        } catch (error) {
            await interaction.editReply({ content: '❌ Failed to purge messages. Messages older than 14 days cannot be bulk deleted.' });
        }
    }
};