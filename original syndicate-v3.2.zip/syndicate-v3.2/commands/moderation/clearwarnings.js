const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { clearWarnings } = require('../../utils/warningsManager');

const LOG_CHANNEL_ID = '899366913086455828';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clearwarnings')
        .setDescription('Clear all warnings for a specific member')
        .addUserOption(option => option.setName('user').setDescription('The user to clear warnings for').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const targetUser = interaction.options.getUser('user');
        
        clearWarnings(interaction.guild.id, targetUser.id);

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🧹 Warnings Cleared')
            .setDescription(`All warnings for ${targetUser} have been successfully reset to 0 by${interaction.user}.`)
            .setTimestamp()
            .setFooter({ text: 'The Syndicate Staff Team' });

        await interaction.editReply({ embeds: [embed] });

        const logChannel = await interaction.guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
        if (logChannel) {
            await logChannel.send({ embeds: [embed] }).catch(() => {});
        }
    }
};