const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getWarnings } = require('../../utils/warningsManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warnings')
        .setDescription('View warning history for a member')
        .addUserOption(option => option.setName('user').setDescription('The user to check').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const targetUser = interaction.options.getUser('user');
        const warningList = getWarnings(interaction.guild.id, targetUser.id);

        const embed = new EmbedBuilder()
            .setColor('#2b2d31')
            .setTitle(`📋 Warning History — ${targetUser.tag}`)
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
            .setTimestamp()
            .setFooter({ text: 'The Syndicate Staff Team' });

        if (warningList.length === 0) {
            embed.setDescription(`${targetUser} has clean records with **0 warnings**.`);
        } else {
            const historyText = warningList.map((w, index) => 
                `**#${index + 1}** | Reason: \`${w.reason}\` | Date: <t:${Math.floor(w.timestamp / 1000)}:R>`
            ).join('\n');
            embed.setDescription(`Total Warnings: **${warningList.length}**\n\n${historyText}`);
        }

        await interaction.editReply({ embeds: [embed] });
    }
};