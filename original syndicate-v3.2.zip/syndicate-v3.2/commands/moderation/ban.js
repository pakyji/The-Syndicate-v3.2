const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const LOG_CHANNEL_ID = '899366913086455828';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a member from the server')
        .addUserOption(option => option.setName('user').setDescription('The user to ban').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('Reason for banning').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const guild = interaction.guild;

        const member = await guild.members.fetch(targetUser.id).catch(() => null);
        if (member) {
            if (targetUser.id === guild.ownerId) return interaction.editReply({ content: '❌ You cannot ban the server owner.' });
            if (member.roles.highest.position >= interaction.member.roles.highest.position && interaction.user.id !== guild.ownerId) {
                return interaction.editReply({ content: '❌ You cannot moderate a user with equal or higher role permissions.' });
            }
        }

        try {
            await guild.members.ban(targetUser.id, { reason });

            const embed = new EmbedBuilder()
                .setColor('#8B0000')
                .setTitle('🔨 Member Banned')
                .addFields(
                    { name: '👤 User', value: `${targetUser.tag} (\`${targetUser.id}\`)`, inline: true },
                    { name: '🛡️ Moderator', value: `${interaction.user.tag}`, inline: true },
                    { name: '📌 Reason', value: `\`\`\`${reason}\`\`\``, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: 'The Syndicate Staff Team' });

            await interaction.editReply({ embeds: [embed] });

            const logChannel = await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
            if (logChannel) await logChannel.send({ embeds: [embed] }).catch(() => {});
        } catch (error) {
            await interaction.editReply({ content: '❌ Failed to ban user. Check bot permissions.' });
        }
    }
};