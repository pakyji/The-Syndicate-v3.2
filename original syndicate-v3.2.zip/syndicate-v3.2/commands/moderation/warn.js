const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { addAndCheckWarning } = require('../../utils/warningsManager');

const LOG_CHANNEL_ID = '899366913086455828';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('Issues a formal warning to a server member')
        .addUserOption(option => option.setName('user').setDescription('The user to warn').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('The reason for the warning').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const guild = interaction.guild;

        const member = await guild.members.fetch(targetUser.id).catch(() => null);
        if (!member) {
            return interaction.editReply({ content: '❌ User not found in this server.' });
        }

        // Hierarchy & Owner Protection
        if (targetUser.id === guild.ownerId) {
            return interaction.editReply({ content: '❌ You cannot warn the server owner.' });
        }
        if (member.roles.highest.position >= interaction.member.roles.highest.position && interaction.user.id !== guild.ownerId) {
            return interaction.editReply({ content: '❌ You cannot moderate a user with equal or higher role permissions.' });
        }

        const totalWarnings = await addAndCheckWarning(guild, targetUser, reason);

        const embed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('⚠️ Warning Issued')
            .setDescription(`Successfully warned ${targetUser.tag}.`)
            .addFields(
                { name: '👤 User', value: `${targetUser} (\`${targetUser.id}\`)`, inline: true },
                { name: '🛡️ Moderator', value: `${interaction.user} (\`${interaction.user.id}\`)`, inline: true },
                { name: '📊 Total Warnings', value: `${totalWarnings}`, inline: true },
                { name: '📌 Reason', value: `\`\`\`${reason}\`\`\``, inline: false }
            )
            .setTimestamp()
            .setFooter({ text: 'The Syndicate Staff Team' });

        await interaction.editReply({ embeds: [embed] });

        const logChannel = await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
        if (logChannel) {
            await logChannel.send({ embeds: [embed] }).catch(() => {});
        }
    }
};