const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const LOG_CHANNEL_ID = '899366913086455828';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a member from the server')
        .addUserOption(option => option.setName('user').setDescription('The user to kick').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('Reason for kicking').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const guild = interaction.guild;

        const member = await guild.members.fetch(targetUser.id).catch(() => null);
        if (!member) return interaction.editReply({ content: '❌ User not found in this server.' });

        if (targetUser.id === guild.ownerId) return interaction.editReply({ content: '❌ You cannot kick the server owner.' });
        if (member.roles.highest.position >= interaction.member.roles.highest.position && interaction.user.id !== guild.ownerId) {
            return interaction.editReply({ content: '❌ You cannot moderate a user with equal or higher role permissions.' });
        }

        try {
            await member.kick(reason);

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('👢 Member Kicked')
                .addFields(
                    { name: '👤 User', value: `${targetUser.tag} (\`${targetUser.id}\`)`, inline: true },
                    { name: '🛡️ Moderator', value: `${interaction.user.tag}`, inline: true },
                    { name: '📌 Reason', value: `\`\`\`${reason}\`\`\``, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: 'The Syndicate Staff Team' });

            await interaction.editReply({ embeds: [embed] });

            const logChannel = await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
            if (logChannel) await logChannel.send({ embeds: [embed] }).catch(() => {});
        } catch (error) {
            await interaction.editReply({ content: '❌ Failed to kick member. Check bot permissions and hierarchy.' });
        }
    }
};