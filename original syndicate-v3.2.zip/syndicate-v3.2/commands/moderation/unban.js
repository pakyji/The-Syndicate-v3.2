const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const LOG_CHANNEL_ID = '899366913086455828';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unban a user by their User ID')
        .addStringOption(option => option.setName('userid').setDescription('The User ID to unban').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('Reason for unbanning').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const userId = interaction.options.getString('userid');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const guild = interaction.guild;

        try {
            await guild.members.unban(userId, reason);

            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('🔓 User Unbanned')
                .addFields(
                    { name: '👤 User ID', value: `\`${userId}\``, inline: true },
                    { name: '🛡️ Moderator', value: `${interaction.user.tag}`, inline: true },
                    { name: '📌 Reason', value: `\`\`\`${reason}\`\`\``, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: 'The Syndicate Staff Team' });

            await interaction.editReply({ embeds: [embed] });

            const logChannel = await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
            if (logChannel) await logChannel.send({ embeds: [embed] }).catch(() => {});
        } catch (error) {
            await interaction.editReply({ content: '❌ Failed to unban user. Make sure the User ID is valid and the user is actually banned.' });
        }
    }
};