const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const LOG_CHANNEL_ID = '899366913086455828';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('untimeout')
        .setDescription('Remove timeout from a member')
        .addUserOption(option => option.setName('user').setDescription('The user to remove timeout from').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('Reason for removing timeout').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const guild = interaction.guild;

        const member = await guild.members.fetch(targetUser.id).catch(() => null);
        if (!member) return interaction.editReply({ content: '❌ User not found in this server.' });

        try {
            await member.timeout(null, reason);

            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('⏳ Timeout Removed')
                .addFields(
                    { name: '👤 User', value: `${targetUser} (\`${targetUser.id}\`)`, inline: true },
                    { name: '🛡️ Moderator', value: `${interaction.user}`, inline: true },
                    { name: '📌 Reason', value: `\`\`\`${reason}\`\`\``, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: 'The Syndicate Staff Team' });

            await interaction.editReply({ embeds: [embed] });

            const logChannel = await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
            if (logChannel) await logChannel.send({ embeds: [embed] }).catch(() => {});
        } catch (error) {
            await interaction.editReply({ content: '❌ Failed to remove timeout.' });
        }
    }
};