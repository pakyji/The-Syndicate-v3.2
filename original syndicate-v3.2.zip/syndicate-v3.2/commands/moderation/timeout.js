const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const LOG_CHANNEL_ID = '899366913086455828';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('Timeout a member for a specified duration')
        .addUserOption(option => option.setName('user').setDescription('The user to timeout').setRequired(true))
        .addIntegerOption(option => option.setName('minutes').setDescription('Duration in minutes (1-40320)').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('Reason for the timeout').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const targetUser = interaction.options.getUser('user');
        const minutes = interaction.options.getInteger('minutes');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const guild = interaction.guild;

        const member = await guild.members.fetch(targetUser.id).catch(() => null);
        if (!member) return interaction.editReply({ content: '❌ User not found in this server.' });

        if (targetUser.id === guild.ownerId) return interaction.editReply({ content: '❌ You cannot timeout the server owner.' });
        if (member.roles.highest.position >= interaction.member.roles.highest.position && interaction.user.id !== guild.ownerId) {
            return interaction.editReply({ content: '❌ You cannot moderate a user with equal or higher role permissions.' });
        }

        try {
            await member.timeout(minutes * 60 * 1000, reason);

            const embed = new EmbedBuilder()
                .setColor('#FFA500')
                .setTitle('⏳ Member Timed Out')
                .addFields(
                    { name: '👤 User', value: `${targetUser} (\`${targetUser.id}\`)`, inline: true },
                    { name: '🛡️ Moderator', value: `${interaction.user}`, inline: true },
                    { name: '⏱️ Duration', value: `${minutes} Minutes`, inline: true },
                    { name: '📌 Reason', value: `\`\`\`${reason}\`\`\``, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: 'The Syndicate Staff Team' });

            await interaction.editReply({ embeds: [embed] });

            const logChannel = await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
            if (logChannel) await logChannel.send({ embeds: [embed] }).catch(() => {});
        } catch (error) {
            await interaction.editReply({ content: '❌ Failed to apply timeout. Check bot role hierarchy.' });
        }
    }
};