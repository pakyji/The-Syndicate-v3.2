// ═══════════════════════════════════════════════
//              THE SYNDICATE V 3.2
//            ROLE ID UTILITY COMMAND
// ═══════════════════════════════════════════════

const { EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'roleid',
    description: 'Fetches the unique Discord ID of a specified role.',
    aliases: ['rid'],
    
    data: new SlashCommandBuilder()
        .setName('roleid')
        .setDescription('Fetches the unique Discord ID of a specified role.')
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('The role to get details for')
                .setRequired(true)
        ),

    async execute(message, args) {
        try {
            if (!message || !message.member) return;

            if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
                return message.reply({ content: '❌ You do not have permission to use this command.' });
            }

            const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);

            if (!role) {
                return message.reply({ content: '❌ Please specify a valid role by mentioning it. Example: `.roleid @RoleName`' });
            }

            const embed = new EmbedBuilder()
                .setTitle('⚜ THE SYNDICATE — ROLE ID UTILITY ⚜')
                .setDescription('* Platform : Ubuntu / Linux\n\nHere are the details for the requested role:')
                .setColor('#2b2d31')
                .addFields(
                    { name: '🛡️ Role Name', value: `${role.name}`, inline: true },
                    { name: '🆔 Role ID', value: `\`${role.id}\``, inline: true },
                    { name: '🎨 Role Color', value: `${role.hexColor}`, inline: true }
                )
                .setImage('https://i.imgur.com/Ie4j48r.jpeg')
                .setFooter({ text: 'Powered by The Syndicate Staff Team • The Syndicate Core - made by ❤️ | Today' })
                .setTimestamp();

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in roleid prefix:', error);
        }
    },

    async executeInteraction(interaction) {
        try {
            if (!interaction.deferred && !interaction.replied) {
                await interaction.deferReply().catch(() => {});
            }

            const role = interaction.options.getRole('role');

            if (!role) {
                return interaction.editReply({ content: '❌ Please specify a valid role.' });
            }

            const embed = new EmbedBuilder()
                .setTitle('⚜ THE SYNDICATE — ROLE ID UTILITY ⚜')
                .setDescription('* Platform : Ubuntu / Linux\n\nHere are the details for the requested role:')
                .setColor('#2b2d31')
                .addFields(
                    { name: '🛡️ Role Name', value: `${role.name}`, inline: true },
                    { name: '🆔 Role ID', value: `\`${role.id}\``, inline: true },
                    { name: '🎨 Role Color', value: `${role.hexColor}`, inline: true }
                )
                .setImage('https://i.imgur.com/Ie4j48r.jpeg')
                .setFooter({ text: 'Powered by The Syndicate Staff Team • The Syndicate Core - made by ❤️ | Today' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in roleid interaction:', error);
            try {
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply({ content: '❌ An error occurred while executing this command.' });
                }
            } catch (e) {}
        }
    }
};