const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

const TARGET_CHANNEL_ID = '901704821357293588';

// Aesthetic aur motivational Unsplash images ki list
const quoteImages = [
    'https://images.unsplash.com/photo-1517649763962-0c623066013b?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?q=80&w=1000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?q=80&w=1000&auto=format&fit=crop'
];

// Rich local quotes pool (External API dependency khatam karne ke liye)
const masterQuotes = [
    { text: "Take your victories, whatever they may be, cherish them, use them, but don't settle for them.", author: "Mia Hamm", topic: "MOTIVATIONAL" },
    { text: "The secret of getting ahead is getting started.", author: "Mark Twain", topic: "SUCCESS" },
    { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius", topic: "PERSEVERANCE" },
    { text: "Everything you’ve ever wanted is on the other side of fear.", author: "George Addair", topic: "GROWTH" },
    { text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau", topic: "SUCCESS" },
    { text: "Hard things will happen to us. We will recover. We will learn from it. We will grow more resilient.", author: "Taylor Swift", topic: "WISDOM" },
    { text: "The only limit to our realization of tomorrow will be our doubts of today.", author: "Franklin D. Roosevelt", topic: "INSPIRATION" },
    { text: "Do not wait to strike till the iron is hot; but make it hot by striking.", author: "William Butler Yeats", topic: "ACTION" },
    { text: "Energy flows where attention goes.", author: "Tony Robbins", topic: "FOCUS" },
    { text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt", topic: "DREAMS" }
];

async function fetchRandomQuote() {
    const randomIndex = Math.floor(Math.random() * masterQuotes.length);
    return masterQuotes[randomIndex];
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('quote')
        .setDescription('Launches a Quote of the Day card with author and topic directly in the target channel!'),

    async execute(interaction) {
        const targetChannel = await interaction.client.channels.fetch(TARGET_CHANNEL_ID).catch(() => null);
        if (!targetChannel) {
            return interaction.reply({ content: `❌ Target channel (<#${TARGET_CHANNEL_ID}>) could not be found!`, flags: [MessageFlags.Ephemeral] });
        }

        await interaction.reply({ content: `💬 Quote card successfully launched in <#${TARGET_CHANNEL_ID}>!`, flags: [MessageFlags.Ephemeral] });

        const quote = await fetchRandomQuote();
        const randomImage = quoteImages[Math.floor(Math.random() * quoteImages.length)];

        const quoteEmbed = new EmbedBuilder()
            .setTitle('🌟 Quote of the Day')
            .setDescription(`*“${quote.text}”*`)
            .setColor('#ffaa00')
            .addFields(
                { name: 'Author', value: `${quote.author}`, inline: false },
                { name: 'Topic', value: `${quote.topic}`, inline: false }
            )
            .setImage(randomImage)
            .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ❤️' })
            .setTimestamp();

        await targetChannel.send({ embeds: [quoteEmbed] });
    },

    startHourlyQuotes(client) {
        console.log('[QUOTE SYSTEM] 30-Minute quote background loop initialized successfully.');
        
        // Function to send quote
        const sendQuote = async () => {
            try {
                const channel = await client.channels.fetch(TARGET_CHANNEL_ID).catch(() => null);
                if (!channel) {
                    console.warn(`[QUOTE SYSTEM WARNING] Target channel ID ${TARGET_CHANNEL_ID} not found during dispatch.`);
                    return;
                }

                const quote = await fetchRandomQuote();
                const randomImage = quoteImages[Math.floor(Math.random() * quoteImages.length)];

                const autoEmbed = new EmbedBuilder()
                    .setTitle('🌟 Quote of the Day (30-Min Interval)')
                    .setDescription(`*“${quote.text}”*`)
                    .setColor('#00ffcc')
                    .addFields(
                        { name: 'Author', value: `${quote.author}`, inline: false },
                        { name: 'Topic', value: `${quote.topic}`, inline: false }
                    )
                    .setImage(randomImage)
                    .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ❤️' })
                    .setTimestamp();

                await channel.send({ embeds: [autoEmbed] });
                console.log(`[QUOTE SYSTEM] Quote successfully dispatched to channel ${TARGET_CHANNEL_ID}`);
            } catch (err) {
                console.error('[QUOTE SYSTEM ERROR] Error sending quote:', err);
            }
        };

        // Bot start hote hi foran ek baar quote bhej de
        sendQuote();

        // Phir har 30 minutes baad bhejta rahe (30 minutes = 30 * 60 * 1000 ms)
        setInterval(sendQuote, 30 * 60 * 1000);
    }
};