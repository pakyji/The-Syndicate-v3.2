const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setupstats')
        .setDescription('Deploys and configures automated real-time server statistics voice channels.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction, client) {
        // Risposta immediata per evitare il timeout di 3 secondi di Discord
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const guild = interaction.guild;

        try {
            // 1. Controllo rapido della categoria esistente
            const existingCategory = guild.channels.cache.find(
                c => c.type === ChannelType.GuildCategory && 
                (c.name.includes('SYNDICATE STATS') || c.name.includes('SERVER STATS'))
            );

            if (existingCategory) {
                return await interaction.editReply({ 
                    content: '⚠️ I canali di statistiche sono già attivi. Elimina la categoria esistente prima di crearne una nuova.' 
                });
            }

            // 2. Creazione immediata della categoria (senza bloccare il thread)
            const category = await guild.channels.create({
                name: '📊 SYNDICATE STATS 📊',
                type: ChannelType.GuildCategory,
                permissionOverwrites: [
                    {
                        id: guild.roles.everyone,
                        deny: [PermissionFlagsBits.Connect],
                    },
                ],
            });

            // 3. Recupero sicuro dei membri in background con fallback sul memberCount
            let totalMembers = guild.memberCount || 0;
            let botsCount = 0;

            try {
                await guild.members.fetch();
                totalMembers = guild.memberCount;
                botsCount = guild.members.cache.filter(m => m.user.bot).size;
            } catch (err) {
                console.log('⚠️ Fetch members warning, using standard memberCount.');
            }

            const humanCount = totalMembers - botsCount;

            // 4. Creazione dei canali vocali dei contatori
            const allChannel = await guild.channels.create({
                name: `👥 All Members: ${totalMembers}`,
                type: ChannelType.GuildVoice,
                parent: category.id,
            });

            const membersChannel = await guild.channels.create({
                name: `👤 Members: ${humanCount}`,
                type: ChannelType.GuildVoice,
                parent: category.id,
            });

            const botsChannel = await guild.channels.create({
                name: `🤖 Bots: ${botsCount}`,
                type: ChannelType.GuildVoice,
                parent: category.id,
            });

            // 5. Salvataggio degli ID per gli aggiornamenti in tempo reale
            if (!client.statsChannels) client.statsChannels = {};
            client.statsChannels[guild.id] = {
                all: allChannel.id,
                members: membersChannel.id,
                bots: botsChannel.id
            };

            // Risposta finale di successo
            await interaction.editReply({ 
                content: '✅ Canali delle statistiche creati con successo!' 
            });

        } catch (error) {
            console.error('Errore critico in setupstats:', error);
            await interaction.editReply({ 
                content: '❌ Si è verificato un errore imprevisto durante la creazione dei canali.' 
            });
        }
    }
};