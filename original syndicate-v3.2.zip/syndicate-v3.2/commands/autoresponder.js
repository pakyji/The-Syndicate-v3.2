const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '../autoresponders.json');

// Helper function to load auto-responses database
function loadResponses() {
    if (!fs.existsSync(dbPath)) {
        fs.writeFileSync(dbPath, JSON.stringify({}));
    }
    try {
        const data = fs.readFileSync(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (e) {
        return {};
    }
}

// Helper function to save auto-responses database
function saveResponses(data) {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

const data = new SlashCommandBuilder()
    .setName('autoresponder')
    .setDescription('Manage automated keyword responses')
    .addSubcommand(subcommand =>
        subcommand
            .setName('add')
            .setDescription('Add a new auto-response trigger')
            .addStringOption(option =>
                option
                    .setName('trigger')
                    .setDescription('The keyword or phrase')
                    .setRequired(true)
            )
            .addStringOption(option =>
                option
                    .setName('response')
                    .setDescription('The bot reply')
                    .setRequired(true)
            )
    )
    .addSubcommand(subcommand =>
        subcommand
            .setName('remove')
            .setDescription('Remove an existing auto-response')
            .addStringOption(option =>
                option
                    .setName('trigger')
                    .setDescription('The trigger to remove')
                    .setRequired(true)
            )
    )
    .addSubcommand(subcommand =>
        subcommand
            .setName('list')
            .setDescription('List all active auto-responses for this server')
    );

module.exports = {
    data,
    async execute(target, isPrefix) {
        let guildId = isPrefix ? target.guild.id : target.guildId;
        let responses = loadResponses();
        
        if (!responses[guildId]) {
            responses[guildId] = {};
        }

        // Handle slash command management
        if (!isPrefix) {
            if (!target.deferred && !target.replied) await target.deferReply();
            const subcommandName = target.options.getSubcommand();

            if (subcommandName === 'add') {
                const trigger = target.options.getString('trigger').toLowerCase();
                const replyText = target.options.getString('response');

                responses[guildId][trigger] = replyText;
                saveResponses(responses);

                const embed = new EmbedBuilder()
                    .setTitle('🤖 Auto-Responder Added')
                    .setDescription(`Trigger: \`${trigger}\`\nResponse: \`${replyText}\``)
                    .setColor('#2ecc71')
                    .setTimestamp();

                return await target.editReply({ embeds: [embed] });
            } 
            else if (subcommandName === 'remove') {
                const trigger = target.options.getString('trigger').toLowerCase();

                if (responses[guildId][trigger]) {
                    delete responses[guildId][trigger];
                    saveResponses(responses);

                    const embed = new EmbedBuilder()
                        .setTitle('🤖 Auto-Responder Removed')
                        .setDescription(`Successfully removed trigger: \`${trigger}\``)
                        .setColor('#e74c3c')
                        .setTimestamp();

                    return await target.editReply({ embeds: [embed] });
                } else {
                    return await target.editReply({ content: `❌ Trigger \`${trigger}\` mojood nahi hai!` });
                }
            }
            else if (subcommandName === 'list') {
                const triggers = Object.keys(responses[guildId]);
                
                const embed = new EmbedBuilder()
                    .setTitle('📜 Server Auto-Responders')
                    .setDescription(triggers.length > 0 ? triggers.map(t => `• \`${t}\``).join('\n') : '❌ Is server par koi auto-responder set nahi hai.')
                    .setColor('#f1c40f')
                    .setTimestamp();

                return await target.editReply({ embeds: [embed] });
            }
        }
    },

    // Optional event listener handler if client supports dynamic event loading, or handled via message check
    async handleMessage(message) {
        if (message.author.bot || !message.guild) return;

        let responses = loadResponses();
        let guildId = message.guild.id;

        if (responses[guildId]) {
            let messageContent = message.content.toLowerCase();
            for (let trigger in responses[guildId]) {
                if (messageContent.includes(trigger)) {
                    await message.reply(responses[guildId][trigger]);
                    break;
                }
            }
        }
    }
};