const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('calculator')
        .setDescription('Open an interactive calculator utility.'),

    async execute(interaction) {
        try {
            let calculationValue = '0';

            const calculatorEmbed = new EmbedBuilder()
                .setColor(0x2b2d31)
                .setTitle('Syndicate Calculator')
                .setDescription(`\`\`\`text\n${calculationValue}\n\`\`\``)
                .setFooter({ text: 'THE SYNDICATE V 3.2 • Calculator Utility' });

            const createCalculatorRows = () => [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('calc_1').setLabel('1').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_2').setLabel('2').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_3').setLabel('3').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_add').setLabel('+').setStyle(ButtonStyle.Success)
                ),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('calc_4').setLabel('4').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_5').setLabel('5').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_6').setLabel('6').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_div').setLabel('/').setStyle(ButtonStyle.Success)
                ),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('calc_7').setLabel('7').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_8').setLabel('8').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_9').setLabel('9').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_mul').setLabel('*').setStyle(ButtonStyle.Success)
                ),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('calc_0').setLabel('0').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_dot').setLabel('.').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_eq').setLabel('=').setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('calc_sub').setLabel('-').setStyle(ButtonStyle.Success)
                ),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('calc_open').setLabel('(').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_close').setLabel(')').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_clear').setLabel('C').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('calc_back').setLabel('<<=').setStyle(ButtonStyle.Danger)
                )
            ];

            const messageResponse = await interaction.reply({
                embeds: [calculatorEmbed],
                components: createCalculatorRows(),
                fetchReply: true
            });

            const componentCollector = messageResponse.createMessageComponentCollector({ time: 180000 });

            componentCollector.on('collect', async buttonInteraction => {
                if (buttonInteraction.user.id !== interaction.user.id) {
                    return buttonInteraction.reply({ content: 'You cannot use this calculator session.', ephemeral: true });
                }

                const buttonId = buttonInteraction.customId;
                if (!buttonId || !buttonId.startsWith('calc_')) return;

                if (buttonId === 'calc_clear') {
                    calculationValue = '0';
                } else if (buttonId === 'calc_back') {
                    calculationValue = calculationValue.length > 1 ? calculationValue.slice(0, -1) : '0';
                } else if (buttonId === 'calc_eq') {
                    try {
                        let evaluatedResult = eval(calculationValue);
                        calculationValue = String(evaluatedResult);
                    } catch (err) {
                        calculationValue = 'Error';
                    }
                } else {
                    const buttonMap = {
                        'calc_0': '0', 'calc_1': '1', 'calc_2': '2', 'calc_3': '3', 'calc_4': '4',
                        'calc_5': '5', 'calc_6': '6', 'calc_7': '7', 'calc_8': '8', 'calc_9': '9',
                        'calc_dot': '.', 'calc_add': '+', 'calc_sub': '-', 'calc_mul': '*', 'calc_div': '/',
                        'calc_open': '(', 'calc_close': ')'
                    };

                    if (buttonMap[buttonId] !== undefined) {
                        if (calculationValue === '0' || calculationValue === 'Error') {
                            calculationValue = buttonMap[buttonId];
                        } else {
                            calculationValue += buttonMap[buttonId];
                        }
                    }
                }

                calculatorEmbed.setDescription(`\`\`\`text\n${calculationValue}\n\`\`\``);
                await buttonInteraction.update({ embeds: [calculatorEmbed], components: createCalculatorRows() });
            });

            componentCollector.on('end', () => {
                const disabledRows = createCalculatorRows().map(row => {
                    row.components.forEach(button => button.setDisabled(true));
                    return row;
                });
                interaction.editReply({ components: disabledRows }).catch(() => {});
            });

        } catch (error) {
            console.error('Calculator Execution Error:', error);
            const errorMessage = '❌ An error occurred while executing the calculator command. Please try again.';
            if (interaction.deferred || interaction.replied) {
                await interaction.editReply({ content: errorMessage, components: [] }).catch(() => {});
            } else {
                await interaction.reply({ content: errorMessage, ephemeral: true }).catch(() => {});
            }
        }
    }
};