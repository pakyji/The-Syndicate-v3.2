const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('translate')
        .setDescription('Translate any message to English and announce it in the support channel!')
        .addStringOption(option =>
            option.setName('text')
                .setDescription('The text you want to translate into English')
                .setRequired(true)
        ),

    async execute(interaction) {
        const user = interaction.user;
        const textToTranslate = interaction.options.getString('text');
        const targetLang = 'en'; // Fixed to English
        const targetChannelId = '1538595475794563167';

        await interaction.reply({ content: '⏳ Translating and sending to the support channel...', ephemeral: true });

        try {
            // Free MyMemory Translation API (Auto detect to English)
            const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(textToTranslate)}&langpair=autodetect\vert{}${targetLang}`;
            
            const response = await fetch(url);
            const data = await response.json();

            if (!data || data.responseStatus !== 200) {
                return interaction.editReply({ 
                    content: '❌ Translation karne mein koi error aaya. Kripya dobara koshish karein.' 
                });
            }

            const translatedText = data.responseData.translatedText;

            // Target channel find karein ID se
            const targetChannel = await interaction.client.channels.fetch(targetChannelId).catch(() => null);

            if (!targetChannel) {
                return interaction.editReply({ 
                    content: '❌ Target channel nahi mila! Kripya channel ID check karein.' 
                });
            }

            // Discord Embed jisme user ka naam, original aur English translation hogi
            const embed = new EmbedBuilder()
                .setColor('#2b2d31')
                .setTitle('🌐 Help Translation Request')
                .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
                .addFields(
                    { name: '📥 Original Message', value: `\`\`\`${textToTranslate}\`\`\``, inline: false },
                    { name: '📤 Translated to English (Help Needed)', value: `\`\`\`${translatedText}\`\`\``, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: 'Powered by The Syndicate Staff Team • Dev: professor0505' });

            // Us fixed channel par message bhej dein
            await targetChannel.send({ embeds: [embed] });

            await interaction.editReply({ 
                content: `✅ Aapka message translate hokar support channel par bhej diya gaya hai!` 
            });

        } catch (error) {
            console.error('Translate Command Error:', error);
            await interaction.editReply({ 
                content: '❌ Process ke dauran ek technical error aa gaya.' 
            });
        }
    }
};