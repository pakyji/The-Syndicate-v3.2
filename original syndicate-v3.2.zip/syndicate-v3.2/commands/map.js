const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('map')
        .setDescription('Search any location or address in the world and view its map!')
        .addStringOption(option =>
            option.setName('query')
                .setDescription('The place, city, or address you want to search (e.g. Eiffel Tower, New York)')
                .setRequired(true)
        ),

    async execute(interaction) {
        // Subito deferred reply bhej dein taaki "The application did not respond" error na aaye
        await interaction.deferReply();

        const searchQuery = interaction.options.getString('query');

        try {
            // Step 1: OpenStreetMap Nominatim API se location fetch karein
            const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`;
            
            const response = await fetch(url, {
                headers: {
                    'User-Agent': 'TheSyndicateBot/3.2 (DiscordBot)'
                }
            });
            const data = await response.json();

            if (!data || data.length === 0) {
                return interaction.editReply({ 
                    content: `❌ Koi aisi location nahi mili: **"${searchQuery}"**. Kripya koi aur sahi naam ya address try karein.` 
                });
            }

            const location = data[0];
            const displayName = location.display_name;
            const lat = location.lat;
            const lon = location.lon;

            // Static map URL (OpenStreetMap static tile alternative)
            const osmStaticMap = `https://staticmap.openstreetmap.de/staticmap.php?center=${lat},${lon}&zoom=14&size=600x300&maptype=mapnik`;

            // Step 2: Discord Embed banayein
            const embed = new EmbedBuilder()
                .setColor('#2b2d31')
                .setTitle('🗺️ World Location Finder')
                .setDescription(`**Address:**\n${displayName}`)
                .addFields(
                    { name: '📍 Latitude', value: `\`${lat}\``, inline: true },
                    { name: '📍 Longitude', value: `\`${lon}\``, inline: true },
                    { name: '🔗 External Link', value: `[Google Maps View](https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(displayName)})`, inline: false }
                )
                .setImage(osmStaticMap)
                .setTimestamp()
                .setFooter({ text: 'Powered by The Syndicate Staff Team • Dev: professor0505' });

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Map Command Error:', error);
            await interaction.editReply({ 
                content: '❌ Location fetch karte waqt ek error aa gaya. Kripya thodi der baad dobara koshish karein.' 
            });
        }
    }
};