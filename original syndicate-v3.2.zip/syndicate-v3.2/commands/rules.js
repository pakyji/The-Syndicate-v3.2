// ═══════════════════════════════════════════════
//              THE SYNDICATE V 3.2
//                 RULES COMMAND
// ═══════════════════════════════════════════════
// Developed & Maintained by The Syndicate Staff Team
// Sends server rules with a gorgeous embed and banner image
// ═══════════════════════════════════════════════

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const DEVELOPER_ID = '877175223504478218';
const RULES_CHANNEL_ID = '902367898327195699';

const data = new SlashCommandBuilder()
    .setName('rules')
    .setDescription('Sends The Syndicate server rules embed to the designated channel');

module.exports = {
    data,
    async execute(target, isPrefix) {
        let user = isPrefix ? target.author : target.user;

        // Ensure only the developer can execute this command
        if (user.id !== DEVELOPER_ID) {
            const errorMsg = '❌ You do not have permission to use this developer-only command.';
            if (isPrefix) return await target.reply(errorMsg);
            if (!target.deferred && !target.replied) await target.deferReply({ ephemeral: true });
            return await target.editReply({ content: errorMsg });
        }

        if (!isPrefix) {
            if (!target.deferred && !target.replied) await target.deferReply({ ephemeral: true });
        }

        try {
            // Find the target channel by its ID
            const channel = await target.client.channels.fetch(RULES_CHANNEL_ID);
            if (!channel) {
                const failMsg = '❌ Error: Rules channel not found!';
                if (isPrefix) return await target.reply(failMsg);
                return await target.editReply({ content: failMsg });
            }

            // Build the comprehensive server rules embed
            const rulesEmbed = new EmbedBuilder()
                .setTitle('⚜ THE SYNDICATE — SERVER RULES ⚜')
                .setDescription('Welcome to **The Syndicate**. To maintain a healthy, safe, and engaging environment, all members must follow the rules listed below.')
                .setColor('#2b2d31')
                .addFields(
                    { name: '1️⃣ Respect Everyone', value: 'Treat all members with respect. No harassment, bullying, racism, discrimination, or personal attacks.', inline: false },
                    { name: '2️⃣ No Toxic Behavior', value: 'Trash talk is fine, but don\'t take it too far. Keep unnecessary drama and arguments out of the server.', inline: false },
                    { name: '3️⃣ No Spam', value: 'Don\'t spam messages, emojis, mentions, stickers, or commands.', inline: false },
                    { name: '4️⃣ No Advertising', value: 'No advertising other Discord servers, social media, services, or websites without staff permission.', inline: false },
                    { name: '5️⃣ No NSFW / Inappropriate Content', value: 'NSFW, disturbing, illegal, or excessively graphic content is strictly prohibited.', inline: false },
                    { name: '6️⃣ No Scamming', value: 'Scamming, fake giveaways, account theft, or misleading members is not allowed.', inline: false },
                    { name: '7️⃣ GTA Rules', value: 'Do not intentionally ruin other members\' gameplay, grief, or abuse glitches/exploits in a way that harms the community.', inline: false },
                    { name: '8️⃣ Follow Staff Instructions', value: 'Listen to moderators and admins. If you disagree with a decision, contact staff privately instead of starting an argument in public channels.', inline: false },
                    { name: '9️⃣ Use the Correct Channels', value: 'Keep conversations in their appropriate channels and follow each channel\'s purpose.', inline: false },
                    { name: '🔟 No Threats', value: 'Real-life threats, doxxing, blackmail, or attempts to expose someone\'s private information will result in immediate action.', inline: false },
                    { name: '1️⃣1️⃣ No Impersonation', value: 'Do not impersonate staff, bots, or other members.', inline: false },
                    { name: '1️⃣2️⃣ Common Sense', value: 'Not every situation can be covered by these rules. Staff may take action against behavior that clearly harms the server or its community.', inline: false },
                    { name: '⚠️ CONSEQUENCES', value: 'Breaking the rules may result in a warning, mute, kick, temporary ban, or permanent ban, depending on the severity of the violation.\n\n*By staying in THE SYNDICATE, you agree to follow these rules.*', inline: false }
                )
                .setImage('https://i.imgur.com/Ie4j48r.jpeg')
                .setFooter({ text: 'The Syndicate Staff Team • Protecting the Community', iconURL: target.client.user.displayAvatarURL() })
                .setTimestamp();

            // Send the embed to the specific channel
            await channel.send({ embeds: [rulesEmbed] });

            const successMsg = `✅ Rules successfully sent to <#${RULES_CHANNEL_ID}>!`;
            if (isPrefix) {
                await target.reply(successMsg);
            } else {
                await target.editReply({ content: successMsg });
            }

        } catch (error) {
            console.error('Failed to send rules embed:', error);
            const errMsg = '❌ An error occurred while sending the rules embed.';
            if (isPrefix) {
                await target.reply(errMsg);
            } else {
                await target.editReply({ content: errMsg });
            }
        }
    }
};

// ╔══════════════════════════════════════════════╗
// ║          THE SYNDICATE V 3.2                ║
// ║                                              ║
// ║   ⚜ POWERED BY THE SYNDICATE STAFF TEAM ⚜   ║
// ║        BUILT • PROTECTED • UNITED            ║
// ╚══════════════════════════════════════════════╝