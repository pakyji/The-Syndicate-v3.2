// ═══════════════════════════════════════════════
//      THE SYNDICATE — REGISTRATION ANNOUNCEMENT
// ═══════════════════════════════════════════════

const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('announce-registration')
        .setDescription('Sends the GamerTag registration announcement to English & Italian channels.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const englishChannelId = '901685831943733268';
        const italianChannelId = '1537221793922940928';

        const englishChannel = interaction.guild.channels.cache.get(englishChannelId);
        const italianChannel = interaction.guild.channels.cache.get(italianChannelId);

        if (!englishChannel || !italianChannel) {
            return interaction.editReply({ content: '⚠️ Error: One or both announcement channels could not be found.' });
        }

        // Buttons row
        const row1 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('reg_pc').setLabel('🖥️ PC').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('reg_pc_enhanced').setLabel('🖥️ PC Enhanced').setStyle(ButtonStyle.Primary)
        );

        const row2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('reg_ps4').setLabel('🎮 PS4').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('reg_ps5').setLabel('🎮 PS5').setStyle(ButtonStyle.Success)
        );

        // 1. English Announcement
        const englishEmbed = new EmbedBuilder()
            .setTitle('🎮 THE SYNDICATE — GAMER PROFILE REGISTRATION')
            .setDescription('> Welcome to **THE SYNDICATE**\n> All existing members must register their gaming profile to maintain crew access.')
            .setColor('#00ffcc')
            .addFields(
                { name: '🪪 GamerTag / PSN ID:', value: '`Not registered`', inline: false },
                { name: '⭐ Rank:', value: '`Not registered`', inline: false },
                { name: '🎮 Platform:', value: '`Not selected`', inline: false }
            )
            .setFooter({ text: 'From The Syndicate Staff Team • Built • Protected • United' })
            .setTimestamp();

        await englishChannel.send({
            content: '@everyone 🚨 **ATTENTION MEMBERS:** Please register your gaming profile using the buttons below!',
            embeds: [englishEmbed],
            components: [row1, row2]
        });

        // 2. Italian Announcement
        const italianEmbed = new EmbedBuilder()
            .setTitle('🎮 THE SYNDICATE — REGISTRAZIONE PROFILO GAMER')
            .setDescription('> Benvenuto in **THE SYNDICATE**\n> Tutti i membri attuali devono registrare il proprio profilo di gioco per mantenere l\'accesso.')
            .setColor('#00ffcc')
            .addFields(
                { name: '🪪 GamerTag / PSN ID:', value: '`Non registrato`', inline: false },
                { name: '⭐ Rank:', value: '`Non registrato`', inline: false },
                { name: '🎮 Platform:', value: '`Non selezionata`', inline: false }
            )
            .setFooter({ text: 'From The Syndicate Staff Team • Built • Protected • United' })
            .setTimestamp();

        await italianChannel.send({
            content: '@everyone 🚨 **ATTENZIONE MEMBRI:** Registrate il vostro profilo di gioco usando i pulsanti sottostanti!',
            embeds: [italianEmbed],
            components: [row1, row2]
        });

        await interaction.editReply({ content: '✅ Registration announcements have been successfully sent to both channels!' });
    }
};