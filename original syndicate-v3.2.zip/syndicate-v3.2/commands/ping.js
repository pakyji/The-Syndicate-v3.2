const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Check bot latency or ping a specific user in Los Santos style!')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('The user you want to ping')
                .setRequired(false)
        ),

    async execute(interaction, isMessageCommand) {
        const targetUser = interaction.options.getUser('target');

        // Invia una risposta temporanea iniziale
        const sent = await interaction.reply({
            content: '🏎️ *Calling Lester to trace the signal...* 🛰️',
            fetchReply: true,
            flags: [MessageFlags.Ephemeral]
        });

        // Calcola la latenza
        const latency = sent.createdTimestamp - interaction.createdTimestamp;
        const apiLatency = Math.round(interaction.client.ws.ping);

        // Frasi divertenti a tema GTA
        const funnyMessages = [
            "The server is smoother than a clean getaway!",
            "Lester is hacking the FIB fiber optics, hold tight.",
            "Mamadou is driving the delivery van and there's heavy traffic in Los Santos!",
            "Trevor is currently chewing on the server cables, give him a second.",
            "We asked Franklin to boost a faster internet connection, but he got distracted by street races.",
            "Even Lamar's roast couldn't burn this fast. Great connection!",
            "Pegasus delivery is delayed because the pilot fell asleep.",
            "Armor and health are fully maxed out. Connection is stable!"
        ];

        let statusMessage = funnyMessages[Math.floor(Math.random() * funnyMessages.length)];
        if (latency > 250) {
            statusMessage = "⚠️ The connection is slower than a Faggio trying to climb Mount Chiliad!";
        }

        const embed = new EmbedBuilder()
            .setTitle('📡 LOS SANTOS NETWORK DIAGNOSTICS')
            .setDescription(`*${statusMessage}*`)
            .setColor('#2b2d31')
            .addFields(
                { name: '⏱️ Roundtrip Latency', value: `\`${latency}ms\``, inline: true },
                { name: '🌐 API WebSocket', value: `\`${apiLatency}ms\``, inline: true }
            )
            .setImage('https://i.imgur.com/Ie4j48r.jpeg')
            .setFooter({ text: 'The Syndicate V • Network Diagnostics' })
            .setTimestamp();

        // Se viene selezionato un utente, invia il messaggio nel canale pubblico taggandolo
        if (targetUser) {
            return await interaction.channel.send({
                content: `🎯 Hey ${targetUser}, you've been pinged by <@${interaction.user.id}>!`,
                embeds: [embed]
            }).then(() => interaction.deleteReply().catch(() => {}));
        }

        // Risposta standard effimera per il controllo diagnostico personale
        await interaction.editReply({
            content: '',
            embeds: [embed]
        });
    },
};