const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

// Simple in-memory balance tracker (can be replaced with your database service if available)
const userBalances = new Map();

// Slot symbols with payout multipliers
const SYMBOLS = ['🍒', '🍋', '🍇', '🔔', '💎', '7️⃣'];
const PAYOUTS = {
    '💎': 10, // Jackpot multiplier
    '7️⃣': 7,
    '🔔': 5,
    '🍇': 3,
    '🍋': 2,
    '🍒': 1.5
};

function getRandomSymbol() {
    return SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
}

module.exports = {
    name: 'slot',
    description: 'Play the casino slot machine and test your luck!',
    categoryHierarchy: ['Economy', 'Casino'],
    data: new SlashCommandBuilder()
        .setName('slot')
        .setDescription('Play the casino slot machine and test your luck!')
        .addIntegerOption(option =>
            option.setName('bet')
                .setDescription('The amount of coins to wager')
                .setRequired(true)
                .setMinValue(10)
                .setMaxValue(10000)
        ),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        const userId = isSlash ? messageOrInteraction.user.id : messageOrInteraction.author.id;
        const userTag = isSlash ? messageOrInteraction.user.tag : messageOrInteraction.author.tag;

        // Fetch bet amount
        const betAmount = isSlash 
            ? messageOrInteraction.options.getInteger('bet')
            : parseInt(messageOrInteraction.content.split(/\s+/)[1]);

        if (isNaN(betAmount) || betAmount <= 0) {
            const errPayload = { content: '❌ Please specify a valid positive bet amount.', flags: [MessageFlags.Ephemeral] };
            return isSlash ? messageOrInteraction.reply(errPayload) : messageOrInteraction.reply(errPayload);
        }

        // Initialize user balance if not present (Starting balance: 1000 coins for testing)
        if (!userBalances.has(userId)) {
            userBalances.set(userId, 1000);
        }

        const currentBalance = userBalances.get(userId);
        if (currentBalance < betAmount) {
            const lowBalPayload = { 
                content: `❌ Insufficient funds! You have **${currentBalance}** coins in your balance.`, 
                flags: [MessageFlags.Ephemeral] 
            };
            return isSlash ? messageOrInteraction.reply(lowBalPayload) : messageOrInteraction.reply(lowBalPayload);
        }

        // Deduct bet amount immediately (Concurrency / Transaction Safety)
        userBalances.set(userId, currentBalance - betAmount);

        // Spin the reels
        const s1 = getRandomSymbol();
        const s2 = getRandomSymbol();
        const s3 = getRandomSymbol();

        let winnings = 0;
        let resultTitle = '🎰 Casino Slot Machine — Better luck next time!';
        let embedColor = '#ED4245'; // Red for loss

        // Check for wins
        if (s1 === s2 && s2 === s3) {
            const multiplier = PAYOUTS[s1] || 2;
            winnings = Math.floor(betAmount * multiplier);
            userBalances.set(userId, userBalances.get(userId) + winnings);
            resultTitle = `🎉 JACKPOT! Three ${s1} in a row!`;
            embedColor = '#57F287'; // Green for win
        } else if (s1 === s2 || s2 === s3 || s1 === s3) {
            winnings = Math.floor(betAmount * 1.25); // Small win for matching two
            userBalances.set(userId, userBalances.get(userId) + winnings);
            resultTitle = '✨ Nice! Two symbols matched!';
            embedColor = '#FEE75C'; // Yellow for minor win
        }

        const newBalance = userBalances.get(userId);

        const slotEmbed = new EmbedBuilder()
            .setColor(embedColor)
            .setTitle(resultTitle)
            .setDescription(`**[ ${s1} | ${s2} | ${s3} ]**`)
            .addFields(
                { name: 'Wager', value: `🪙 ${betAmount} coins`, inline: true },
                { name: 'Payout', value: `🪙 ${winnings} coins`, inline: true },
                { name: 'New Balance', value: `🪙 ${newBalance} coins`, inline: true }
            )
            .setTimestamp()
            .setFooter({ text: `Player: ${userTag} • The Syndicate V3.2 Economy` });

        const replyPayload = {
            embeds: [slotEmbed],
            flags: isSlash ? [MessageFlags.Ephemeral] : []
        };

        await messageOrInteraction.reply(replyPayload);
    }
};