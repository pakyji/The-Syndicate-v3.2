const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

const userBalances = new Map();

const PRIZES = [
    { name: 'Stolen Watch & Cash', amount: 500, chance: 0.40 },
    { name: 'Bunker Weapon Shipment', amount: 2500, chance: 0.25 },
    { name: 'Diamond Casino Vault Bag', amount: 7500, chance: 0.15 },
    { name: 'Cayo Perico Panther Statue', amount: 25000, chance: 0.05 },
    { name: "JACKPOT: El Patron's Secret Safe", amount: 100000, chance: 0.01 },
    { name: 'Busted! (Nothing)', amount: 0, chance: 0.13 }
];

const TICKET_COST = 1000;

module.exports = {
    name: 'scratch',
    description: 'Buy and scratch a GTA underworld scratch card for massive cash prizes!',
    categoryHierarchy: ['Economy', 'Casino'],
    data: new SlashCommandBuilder()
        .setName('scratch')
        .setDescription('Buy and scratch an underground scratch card!')
        .addStringOption(option =>
            option.setName('card')
                .setDescription('Choose your scratch card type')
                .setRequired(true)
                .addChoices(
                    { name: 'The Milionario (Classic GTA Heist Scratch)', value: 'milionario' },
                    { name: 'Cayo Perico Gold Card (High Roller)', value: 'cayoperico' }
                )
        ),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        const userId = isSlash ? messageOrInteraction.user.id : messageOrInteraction.author.id;
        const userTag = isSlash ? messageOrInteraction.user.tag : messageOrInteraction.author.tag;

        if (!userBalances.has(userId)) userBalances.set(userId, 5000);
        let balance = userBalances.get(userId);

        if (balance < TICKET_COST) {
            const lowBal = { content: `❌ You need at least **🪙 ${TICKET_COST} coins** to buy a scratch card! Current balance: 🪙 ${balance}`, flags: [MessageFlags.Ephemeral] };
            return isSlash ? messageOrInteraction.reply(lowBal) : messageOrInteraction.reply(lowBal);
        }

        balance -= TICKET_COST;
        userBalances.set(userId, balance);

        const randomRoll = Math.random();
        let cumulative = 0;
        let selectedPrize = PRIZES[0];

        for (const prize of PRIZES) {
            cumulative += prize.chance;
            if (randomRoll <= cumulative) {
                selectedPrize = prize;
                break;
            }
        }

        if (selectedPrize.amount > 0) {
            balance += selectedPrize.amount;
            userBalances.set(userId, balance);
        }

        const isWin = selectedPrize.amount > 0;

        const initialEmbed = new EmbedBuilder()
            .setColor('#2B2D31')
            .setTitle(`🎫 THE SYNDICATE • SCRATCH & WIN`)
            .setDescription(`You purchased a scratch card for **🪙 ${TICKET_COST} coins**!\nClick the button below to scratch and reveal your prize symbols!`)
            .addFields(
                { name: 'Card Grid', value: `|| 💰 || || 💎 || || 🪙 ||\n|| 💵 || || 🎲 || || 👑 ||`, inline: false },
                { name: 'Wallet Balance', value: `🪙 ${balance} coins`, inline: true }
            )
            .setFooter({ text: `Player: ${userTag} • Scratch Card Bureau` });

        const scratchButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('reveal_card')
                .setLabel('🪧 Scratch Card Now')
                .setStyle(ButtonStyle.Success)
        );

        const response = await messageOrInteraction.reply({ embeds: [initialEmbed], components: [scratchButton], fetchReply: true });

        const collector = response.createMessageComponentCollector({ time: 30000 });

        collector.on('collect', async i => {
            if (i.user.id !== userId) {
                return i.reply({ content: `❌ This is not your scratch card! Buy your own using \`/scratch\`.`, flags: [MessageFlags.Ephemeral] });
            }

            // Riconosce e gestisce correttamente l'interazione del bottone senza blocchi
            await i.deferUpdate();

            const resultEmbed = new EmbedBuilder()
                .setColor(isWin ? '#57F287' : '#ED4245')
                .setTitle(isWin ? `🎉 VINTI QUI! • SCRATCH CARD WINNER!` : `🚨 BUSTED! • SCRATCH CARD LOSS`)
                .setDescription(isWin 
                    ? `Congratulations! You scratched off the winning combination and secured a major payout for **The Syndicate**!` 
                    : `Bad luck! All the boxes revealed empty pockets and police badges. Better luck next time!`
                )
                .addFields(
                    { name: '🪧 Scratched Prize', value: `**${selectedPrize.name}**`, inline: true },
                    { name: '🪙 Payout Amount', value: `**🪙 ${selectedPrize.amount.toLocaleString()} coins**`, inline: true },
                    { name: '💰 Updated Balance', value: `🪙 ${balance} coins`, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: `Winner: ${userTag} • Tabaccheria Del Syndicate V3.2` });

            if (isWin) {
                resultEmbed.setImage('https://media.giphy.com/media/l0HlRnAWXxn0MhOBK/giphy.gif');
            }

            await i.editReply({ embeds: [resultEmbed], components: [] });
            collector.stop();
        });
    }
};