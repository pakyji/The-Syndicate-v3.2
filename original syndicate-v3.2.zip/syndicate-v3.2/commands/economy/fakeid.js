const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

// Expanded pools for endless customization and variety
const ALIASES = [
    'The Ghost', 'Shadow Walker', 'Neon Viper', 'Silent Phantom', 
    'Zero Cool', 'Iron Syndicate', 'Black Widow', 'Cyber Ronin',
    'Venom Strike', 'Glitch Master', 'Grim Reaper', 'Phantom X',
    'Blood Hound', 'Cyber Nomad', 'The Oracle', 'Scarface'
];

const ORGANIZATIONS = [
    'The Syndicate Cartel', 'Los Santos Underground', 'Cyber Syndicate', 
    'Liberty City Network', 'Diamond Division', 'Midnight Syndicate',
    'Cayo Perico Remnants', 'Yakuza Vanguard'
];

const CRIMES = [
    'Crypto Heist & Data Breach', 'Vault Cracking & Armed Robbery', 
    'Underground Casino Fraud', 'High-Speed Vehicle Theft', 
    'Black Market Arms Dealing', 'Classified Intel Smuggling',
    'El Patron Compound Infiltration', 'Federal Reserve Cyber Raid'
];

const RANKS = [
    'Novice Pickpocket', 'Street Enforcer', 'Vault Specialist', 
    'Syndicate Commander', 'Underworld Kingpin', 'Legendary Mastermind'
];

const STATUSES = ['WANTED DEAD OR ALIVE', 'ACTIVE FUGITIVE', 'UNDERCOVER AGENT', 'SYNNDICATE ELITE'];

module.exports = {
    name: 'fakeid',
    description: 'Generate an advanced top-secret underworld fake ID card!',
    categoryHierarchy: ['Economy', 'Fun'],
    data: new SlashCommandBuilder()
        .setName('fakeid')
        .setDescription('Generate an advanced top-secret underworld fake ID card!')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('Optional: Generate a fake ID for another user')
                .setRequired(false)
        ),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        
        // Determine the target user (self or mentioned user)
        const targetUser = isSlash 
            ? (messageOrInteraction.options.getUser('target') || messageOrInteraction.user)
            : messageOrInteraction.author;

        // Random selections from arrays
        const randomAlias = ALIASES[Math.floor(Math.random() * ALIASES.length)];
        const randomOrg = ORGANIZATIONS[Math.floor(Math.random() * ORGANIZATIONS.length)];
        const randomCrime = CRIMES[Math.floor(Math.random() * CRIMES.length)];
        const randomRank = RANKS[Math.floor(Math.random() * RANKS.length)];
        const randomStatus = STATUSES[Math.floor(Math.random() * STATUSES.length)];
        
        // Randomized stats
        const idNumber = Math.floor(Math.random() * 90000000) + 10000000;
        const bountyCoins = Math.floor(Math.random() * 45000) + 5000; // 5k to 50k bounty
        const clearanceLevel = Math.floor(Math.random() * 5) + 1; // Level 1 to 5

        // Mock Issue & Expiry Years
        const currentYear = new Date().getFullYear();
        const issueYear = currentYear - Math.floor(Math.random() * 3);
        const expiryYear = issueYear + 5;

        const idEmbed = new EmbedBuilder()
            .setColor('#2B2D31') // Sleek dark theme
            .setTitle(`🪪 THE SYNDICATE • CLASSIFIED PASSPORT`)
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
            .setDescription(`*Underground Security Bureau • Official Citizen Dossier*`)
            .addFields(
                { name: '👤 Legal Name', value: `\`${targetUser.username}\``, inline: true },
                { name: '🕵️ Underworld Alias', value: `\`${randomAlias}\``, inline: true },
                { name: '🆔 Syndicate ID', value: `\`SYN-${idNumber}\``, inline: true },
                
                { name: '🏢 Faction / Org', value: `\`${randomOrg}\``, inline: true },
                { name: '⭐ Syndicate Rank', value: `\`${randomRank}\``, inline: true },
                { name: '🔒 Clearance Level', value: `\`Level ${clearanceLevel} Operative\``, inline: true },
                
                { name: '⚠️ Primary Offense', value: `\`${randomCrime}\``, inline: false },
                
                { name: '💰 Current Bounty', value: `🪙 **${bountyCoins.toLocaleString()} coins**`, inline: true },
                { name: '📅 Validity', value: `\`${issueYear} — ${expiryYear}\``, inline: true },
                { name: '📋 Threat Status', value: `**[ ${randomStatus} ]**`, inline: false }
            )
            .setImage('https://media.giphy.com/media/xT9IgzoKnwFNmISR8I/giphy.gif')
            .setTimestamp()
            .setFooter({ text: `Target Account ID: ${targetUser.id} • Verified Record` });

        await messageOrInteraction.reply({
            embeds: [idEmbed],
            flags: isSlash ? [] : []
        });
    }
};