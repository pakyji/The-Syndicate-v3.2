const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

const userBalances = new Map();
const robCooldowns = new Map();
const COOLDOWN_TIME = 35 * 1000; // 35 seconds cooldown

module.exports = {
    name: 'rob',
    description: 'Attempt a bank heist or pickpocket another user!',
    categoryHierarchy: ['Economy', 'Casino'],
    data: new SlashCommandBuilder()
        .setName('rob')
        .setDescription('Attempt a bank heist or pickpocket another user!')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('Optional: The user you want to pickpocket')
                .setRequired(false)
        ),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        const robberId = isSlash ? messageOrInteraction.user.id : messageOrInteraction.author.id;
        const robberTag = isSlash ? messageOrInteraction.user.tag : messageOrInteraction.author.tag;

        const targetUser = isSlash ? messageOrInteraction.options.getUser('target') : null;

        // Check Cooldown
        const now = Date.now();
        if (robCooldowns.has(robberId)) {
            const expirationTime = robCooldowns.get(robberId) + COOLDOWN_TIME;
            if (now < expirationTime) {
                const timeLeft = Math.ceil((expirationTime - now) / 1000);
                const cdPayload = { 
                    content: `⏳ The police are still alert! Please wait **${timeLeft} seconds** before your next crime.`, 
                    flags: [MessageFlags.Ephemeral] 
                };
                return isSlash ? messageOrInteraction.reply(cdPayload) : messageOrInteraction.reply(cdPayload);
            }
        }
        robCooldowns.set(robberId, now);

        // Initialize balances
        if (!userBalances.has(robberId)) userBalances.set(robberId, 1000);
        const robberBalance = userBalances.get(robberId);

        // --- SCENARIO A: USER ROBBERY ---
        if (targetUser) {
            if (targetUser.id === robberId) {
                const selfPayload = { content: '❌ You cannot rob yourself!', flags: [MessageFlags.Ephemeral] };
                return isSlash ? messageOrInteraction.reply(selfPayload) : messageOrInteraction.reply(selfPayload);
            }
            if (targetUser.bot) {
                const botPayload = { content: '❌ You cannot rob a bot. They have no pockets!', flags: [MessageFlags.Ephemeral] };
                return isSlash ? messageOrInteraction.reply(botPayload) : messageOrInteraction.reply(botPayload);
            }

            if (!userBalances.has(targetUser.id)) userBalances.set(targetUser.id, 1000);
            const targetBalance = userBalances.get(targetUser.id);

            if (robberBalance < 100) {
                const lowBalPayload = { content: `❌ You need at least **100 coins** for bail money if caught!`, flags: [MessageFlags.Ephemeral] };
                return isSlash ? messageOrInteraction.reply(lowBalPayload) : messageOrInteraction.reply(lowBalPayload);
            }
            if (targetBalance < 150) {
                const poorPayload = { content: `❌ **${targetUser.username}** is too broke right now. Not worth it!`, flags: [MessageFlags.Ephemeral] };
                return isSlash ? messageOrInteraction.reply(poorPayload) : messageOrInteraction.reply(poorPayload);
            }

            const isSuccess = Math.random() < 0.40;
            let amount = 0;
            let title = '';
            let color = '';

            if (isSuccess) {
                const percentage = Math.random() * 0.20 + 0.10;
                amount = Math.floor(targetBalance * percentage);
                userBalances.set(targetUser.id, targetBalance - amount);
                userBalances.set(robberId, robberBalance + amount);
                title = `🥷 Successful Pickpocket on ${targetUser.username}!`;
                color = '#57F287';
            } else {
                amount = Math.floor(Math.random() * 101) + 100;
                userBalances.set(robberId, Math.max(0, robberBalance - amount));
                title = `🚨 Caught Pickpocketing ${targetUser.username}!`;
                color = '#ED4245';
            }

            const newBal = userBalances.get(robberId);
            const embed = new EmbedBuilder()
                .setColor(color)
                .setTitle(title)
                .addFields(
                    { name: isSuccess ? 'Stolen Cash' : 'Fine Paid', value: `🪙 ${amount} coins`, inline: true },
                    { name: 'Your New Balance', value: `🪙 ${newBal} coins`, inline: true }
                )
                .setTimestamp()
                .setFooter({ text: `Player: ${robberTag} • The Syndicate V3.2 Economy` });

            return isSlash ? messageOrInteraction.reply({ embeds: [embed] }) : messageOrInteraction.reply({ embeds: [embed] });
        }

        // --- SCENARIO B: BANK HEIST ---
        if (robberBalance < 50) {
            const lowBalPayload = { content: `❌ You need at least **50 coins** to buy bank heist tools!`, flags: [MessageFlags.Ephemeral] };
            return isSlash ? messageOrInteraction.reply(lowBalPayload) : messageOrInteraction.reply(lowBalPayload);
        }

        const isBankSuccess = Math.random() < 0.45;
        let bankAmount = 0;
        let bankTitle = '';
        let bankColor = '';

        if (isBankSuccess) {
            bankAmount = Math.floor(Math.random() * 601) + 200;
            userBalances.set(robberId, robberBalance + bankAmount);
            bankTitle = '🚨 SUCCESS! Bank Vault Breached!';
            bankColor = '#57F287';
        } else {
            bankAmount = Math.floor(Math.random() * 201) + 100;
            userBalances.set(robberId, Math.max(0, robberBalance - bankAmount));
            bankTitle = '🚔 CAUGHT BY POLICE! Bank Heist Failed!';
            bankColor = '#ED4245';
        }

        const newBankBal = userBalances.get(robberId);
        const bankEmbed = new EmbedBuilder()
            .setColor(bankColor)
            .setTitle(bankTitle)
            .addFields(
                { name: isBankSuccess ? 'Stolen Loot' : 'Fine Paid', value: `🪙 ${bankAmount} coins`, inline: true },
                { name: 'New Balance', value: `🪙 ${newBankBal} coins`, inline: true }
            )
            .setTimestamp()
            .setFooter({ text: `Player: ${robberTag} • The Syndicate V3.2 Economy` });

        await messageOrInteraction.reply({ embeds: [bankEmbed] });
    }
};