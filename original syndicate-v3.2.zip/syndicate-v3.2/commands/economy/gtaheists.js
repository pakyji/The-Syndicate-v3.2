const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

// Shared balance tracker
const userBalances = new Map();

// A-to-Z GTA Online Heists Registry
const GTA_HEISTS = [
    { id: 'fleeca', name: 'The Fleeca Job', payout: 150000, cost: 15000, minCrew: 2, maxCrew: 2, desc: 'A quick and dirty bank job in Little Seoul.' },
    { id: 'prison', name: 'The Prison Break', payout: 500000, cost: 40000, minCrew: 4, maxCrew: 4, desc: 'Infiltrate Bolingbroke Penitentiary to extract Maxim Rashkovsky.' },
    { id: 'humane', name: 'The Humane Labs Raid', payout: 675000, cost: 54000, minCrew: 4, maxCrew: 4, desc: 'Steal confidential research data from a biotech facility.' },
    { id: 'seriesA', name: 'Series A Funding', payout: 505000, cost: 40400, minCrew: 4, maxCrew: 4, desc: 'Hijack multiple drug shipments across Blaine County.' },
    { id: 'pacStandard', name: 'Pacific Standard Job', payout: 1250000, cost: 100000, minCrew: 4, maxCrew: 4, desc: 'The ultimate classic downtown Los Santos bank vault assault.' },
    { id: 'doomsday', name: 'The Doomsday Scenario', payout: 2100000, cost: 165000, minCrew: 2, maxCrew: 4, desc: 'Prevent a global apocalypse inside Mount Chiliad facility.' },
    { id: 'diamond', name: 'The Diamond Casino Heist', payout: 3600000, cost: 25000, minCrew: 2, maxCrew: 4, desc: 'Infiltrate Vault contents via Silent & Sneaky or Aggressive force.' },
    { id: 'cayoPerico', name: 'The Cayo Perico Heist', payout: 4500000, cost: 25000, minCrew: 1, maxCrew: 4, desc: 'Solo or crew stealth infiltration of El Rubio’s private island fortress.' }
];

module.exports = {
    name: 'gtaheists',
    description: 'Launch A-to-Z GTA Online Heists as a registered CEO and recruit your crew!',
    categoryHierarchy: ['Economy', 'Heists'],
    data: new SlashCommandBuilder()
        .setName('gtaheists')
        .setDescription('Organize a GTA heist as CEO and assemble your crew.')
        .addStringOption(option =>
            option.setName('heist')
                .setDescription('Select the heist operation')
                .setRequired(true)
                .addChoices(...GTA_HEISTS.map(h => ({ name: `${h.name} (Payout: 🪙 ${h.payout.toLocaleString()})`, value: h.id })))
        )
        .addStringOption(option =>
            option.setName('ceoname')
                .setDescription('Enter your CEO Organization / Syndicate Name (e.g., Los Santos Cartel)')
                .setRequired(true)
        ),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        const userId = isSlash ? messageOrInteraction.user.id : messageOrInteraction.author.id;
        const userTag = isSlash ? messageOrInteraction.user.tag : messageOrInteraction.author.tag;

        const heistId = isSlash ? messageOrInteraction.options.getString('heist') : 'fleeca';
        const ceoName = isSlash ? messageOrInteraction.options.getString('ceoname') : 'Syndicate Cartel';
        const selectedHeist = GTA_HEISTS.find(h => h.id === heistId);

        // Initialize balances
        if (!userBalances.has(userId)) userBalances.set(userId, 50000);
        let balance = userBalances.get(userId);

        if (balance < selectedHeist.cost) {
            const lowBal = { content: `❌ CEO **${ceoName}**, you need at least **🪙 ${selectedHeist.cost.toLocaleString()} coins** setup fee for **${selectedHeist.name}**! Current balance: 🪙 ${balance.toLocaleString()}`, flags: [MessageFlags.Ephemeral] };
            return isSlash ? messageOrInteraction.reply(lowBal) : messageOrInteraction.reply(lowBal);
        }

        // Deduct setup cost
        balance -= selectedHeist.cost;
        userBalances.set(userId, balance);

        // Crew list tracking
        const crewMembers = [userId]; // CEO is automatically member #1

        // Lobby Embed
        const lobbyEmbed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle(`🏢 CEO HEIST LOBBY • ${ceoName.toUpperCase()}`)
            .setDescription(`**Target Heist:** ${selectedHeist.name}\n\n*${selectedHeist.desc}*\n\n` +
                `📋 **Intel & Financials:**\n` +
                `• Setup Cost Paid: \`🪙 ${selectedHeist.cost.toLocaleString()}\`\n` +
                `• Potential Total Payout: \`🪙 ${selectedHeist.payout.toLocaleString()}\`\n` +
                `• Required Crew Size: \`${selectedHeist.minCrew} -${selectedHeist.maxCrew} Players\`\n\n` +
                `👥 **Current Recruited Crew (${crewMembers.length}/${selectedHeist.maxCrew}):**\n` +
                `1. <@${userId}> (CEO)`
            )
            .setThumbnail('https://images.unsplash.com/photo-1542751371-adc38448a05e')
            .setFooter({ text: `CEO Boss: ${userTag} • Click buttons below to join or launch!` });

        const lobbyButtons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('join_crew')
                .setLabel('🤝 Join Heist Crew')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('launch_heist')
                .setLabel('🚀 Launch Operation')
                .setStyle(ButtonStyle.Primary)
        );

        const response = await messageOrInteraction.reply({ embeds: [lobbyEmbed], components: [lobbyButtons], fetchReply: true });

        const collector = response.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', async i => {
            try {
                if (i.customId === 'join_crew') {
                    if (crewMembers.includes(i.user.id)) {
                        return await i.reply({ content: `⚠️ You are already part of this CEO crew!`, flags: [MessageFlags.Ephemeral] });
                    }
                    if (crewMembers.length >= selectedHeist.maxCrew) {
                        return await i.reply({ content: `❌ This CEO crew is already full (Max ${selectedHeist.maxCrew} players)!`, flags: [MessageFlags.Ephemeral] });
                    }

                    crewMembers.push(i.user.id);
                    await i.deferUpdate();

                    const updatedEmbed = EmbedBuilder.from(lobbyEmbed)
                        .setFields({
                            name: `👥 Current Recruited Crew (${crewMembers.length}/${selectedHeist.maxCrew}):`,
                            value: crewMembers.map((id, idx) => `${idx + 1}. <@${id}> ${idx === 0 ? '(CEO)' : '(Associate)'}`).join('\n'),
                            inline: false
                        });

                    await i.editReply({ embeds: [updatedEmbed] });
                }

                if (i.customId === 'launch_heist') {
                    if (i.user.id !== userId) {
                        return await i.reply({ content: `❌ Only the CEO (<@${userId}>) can launch this operation!`, flags: [MessageFlags.Ephemeral] });
                    }

                    // Strict check for classic apartment heists that require exactly 4 players
                    if (selectedHeist.minCrew === 4 && crewMembers.length < 4) {
                        return await i.reply({ 
                            content: `❌ **Apartment Heist Error:** You cannot launch **${selectedHeist.name}** alone or with an incomplete team! You need **exactly 4 users** in your crew. Current members: **${crewMembers.length}/4**.`, 
                            flags: [MessageFlags.Ephemeral] 
                        });
                    }

                    // General minimum check for other heists
                    if (crewMembers.length < selectedHeist.minCrew) {
                        return await i.reply({ content: `⚠️ You need at least **${selectedHeist.minCrew} players** in your crew to launch **${selectedHeist.name}**!`, flags: [MessageFlags.Ephemeral] });
                    }

                    await i.deferUpdate();

                    const isSuccess = Math.random() < 0.70;
                    const individualShare = Math.floor(selectedHeist.payout / crewMembers.length);

                    if (isSuccess) {
                        for (const memberId of crewMembers) {
                            let memberBal = userBalances.get(memberId) || 50000;
                            memberBal += individualShare;
                            userBalances.set(memberId, memberBal);
                        }
                    }

                    const resultEmbed = new EmbedBuilder()
                        .setColor(isSuccess ? '#57F287' : '#ED4245')
                        .setTitle(isSuccess ? `🏆 CEO HEIST SUCCESSFUL! • ${ceoName.toUpperCase()}` : `🚨 LSPD AMBUSH! • HEIST FAILED`)
                        .setDescription(isSuccess
                            ? `Under CEO **${ceoName}**, the crew pulled off **${selectedHeist.name}** without a hitch! The vault is cleared and security systems were bypassed.`
                            : `The FIB and LSPD caught wind of the operation! The crew got pinned down, equipment was lost, and the loot was seized.`
                        )
                        .addFields(
                            { name: 'Operation', value: `🎯 ${selectedHeist.name}`, inline: true },
                            { name: 'Crew Payout Split', value: isSuccess ? `🪙 ${individualShare.toLocaleString()} coins each` : `🪙 0 coins (Loss)`, inline: true },
                            { name: 'Participating Crew', value: crewMembers.map(id => `<@${id}>`).join(', '), inline: false }
                        )
                        .setTimestamp()
                        .setFooter({ text: `The Syndicate V3.2 • Secure Heist Ledger` });

                    if (isSuccess) {
                        resultEmbed.setImage('https://media.giphy.com/media/l0HlRnAWXxn0MhOBK/giphy.gif');
                    }

                    await i.editReply({ embeds: [resultEmbed], components: [] });
                    collector.stop();
                }
            } catch (err) {
                console.error("Error in gtaheists interaction:", err);
            }
        });
    }
};