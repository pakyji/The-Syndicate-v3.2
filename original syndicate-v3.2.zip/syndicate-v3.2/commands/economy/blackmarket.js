const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

// Shared balance tracker (synchronized with all economy modules)
const userBalances = new Map();

// Black Market Inventory Items
const SHOP_ITEMS = [
    { id: 'passport', name: 'Forged Syndicate Passport', price: 2500, description: 'Erase your criminal record temporarily and dodge police bounties.' },
    { id: 'armor', name: 'Ballistic Heavy Armor', price: 5000, description: 'Boost your survival rating for upcoming high-stakes heists.' },
    { id: 'diamonds', name: 'Smuggled Diamond Stash', price: 10000, description: 'A high-value asset shipped directly from the Cayo Perico vaults.' }
];

module.exports = {
    name: 'blackmarket',
    description: 'Access the underground black market to purchase illicit gear and credentials.',
    categoryHierarchy: ['Economy', 'Shop'],
    data: new SlashCommandBuilder()
        .setName('blackmarket')
        .setDescription('Access the underground black market shop.'),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        const userId = isSlash ? messageOrInteraction.user.id : messageOrInteraction.author.id;
        const userTag = isSlash ? messageOrInteraction.user.tag : messageOrInteraction.author.tag;

        // Initialize balance if not present
        if (!userBalances.has(userId)) userBalances.set(userId, 15000);
        let balance = userBalances.get(userId);

        // Shop Interface Embed
        const marketEmbed = new EmbedBuilder()
            .setColor('#2B2D31')
            .setTitle(`🏴‍☠️ THE SYNDICATE • BLACK MARKET SHOP`)
            .setDescription(`Welcome to the underground trading post. Spend your earned syndicate cash on high-tier illicit gear and forged credentials.`)
            .setThumbnail('https://images.unsplash.com/photo-1526304640581-d334cdbbf45e')
            .addFields(
                SHOP_ITEMS.map((item, index) => ({
                    name: `${index + 1}.${item.name}`,
                    value: `Price: \`🪙 ${item.price.toLocaleString()} coins\`\n*${item.description}*`,
                    inline: false
                })),
                { name: '💰 Current Wallet Balance', value: `🪙 ${balance.toLocaleString()} coins`, inline: false }
            )
            .setFooter({ text: `Player: ${userTag} • Secure Trade Network V3.2` });

        // Action Buttons for purchasing items
        const shopButtons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('buy_passport')
                .setLabel('🪪 Buy Passport')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('buy_armor')
                .setLabel('🛡️ Buy Armor')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('buy_diamonds')
                .setLabel('💎 Buy Diamonds')
                .setStyle(ButtonStyle.Success)
        );

        const response = await messageOrInteraction.reply({ embeds: [marketEmbed], components: [shopButtons], fetchReply: true });

        // Component Collector for button interactions
        const collector = response.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', async i => {
            try {
                if (i.user.id !== userId) {
                    return await i.reply({ content: `❌ This is not your black market session! Run \`/blackmarket\` to open your own shop.`, flags: [MessageFlags.Ephemeral] });
                }

                // Acknowledge the interaction right away to prevent loading failures
                if (!i.deferred && !i.replied) {
                    await i.deferUpdate();
                }

                let purchasedItem = null;
                if (i.customId === 'buy_passport') purchasedItem = SHOP_ITEMS[0];
                if (i.customId === 'buy_armor') purchasedItem = SHOP_ITEMS[1];
                if (i.customId === 'buy_diamonds') purchasedItem = SHOP_ITEMS[2];

                if (!purchasedItem) return;

                // Fetch current user balance
                let currentBal = userBalances.get(userId) || 15000;

                if (currentBal < purchasedItem.price) {
                    const failEmbed = new EmbedBuilder()
                        .setColor('#ED4245')
                        .setTitle(`❌ TRANSACTION FAILED`)
                        .setDescription(`You don't have enough coins to buy the **${purchasedItem.name}**!\nRequired: \`🪙 ${purchasedItem.price.toLocaleString()}\` | Your Balance: \`🪙 ${currentBal.toLocaleString()}\``)
                        .setFooter({ text: `The Syndicate V3.2 Black Market` });
                    
                    return await i.followUp({ embeds: [failEmbed], flags: [MessageFlags.Ephemeral] });
                }

                // Deduct balance and update map
                currentBal -= purchasedItem.price;
                userBalances.set(userId, currentBal);

                // Success receipt embed
                const successEmbed = new EmbedBuilder()
                    .setColor('#57F287')
                    .setTitle(`🛍️ PURCHASE SUCCESSFUL!`)
                    .setDescription(`You have successfully acquired **${purchasedItem.name}** from the underground syndicate ledger.`)
                    .addFields(
                        { name: 'Item Acquired', value: `📦 ${purchasedItem.name}`, inline: true },
                        { name: 'Cost Paid', value: `🪙 ${purchasedItem.price.toLocaleString()} coins`, inline: true },
                        { name: 'Remaining Balance', value: `🪙 ${currentBal.toLocaleString()} coins`, inline: false }
                    )
                    .setTimestamp()
                    .setFooter({ text: `Buyer: ${userTag} • Secure Transaction Log` });

                await i.editReply({ embeds: [successEmbed], components: [] });
                collector.stop();
            } catch (error) {
                console.error("Error handling black market button click:", error);
            }
        });
    }
};