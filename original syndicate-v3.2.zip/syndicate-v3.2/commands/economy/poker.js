const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

// Shared in-memory balance tracker (matches your slot economy module)
const userBalances = new Map();

// Card suits and values
const SUITS = ['♠️', '♥️', '♦️', '♣️'];
const VALUES = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
const VALUE_MAP = { '2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, '10':10, 'J':11, 'Q':12, 'K':13, 'A':14 };

function getRandomCard() {
    const suit = SUITS[Math.floor(Math.random() * SUITS.length)];
    const value = VALUES[Math.floor(Math.random() * VALUES.length)];
    return { suit, value, weight: VALUE_MAP[value] };
}

function evaluateHand(cards) {
    // Sort cards by weight
    cards.sort((a, b) => a.weight - b.weight);

    const values = cards.map(c => c.value);
    const suits = cards.map(c => c.suit);
    const weights = cards.map(c => c.weight);

    const isFlush = suits.every(s => s === suits[0]);
    
    let isStraight = false;
    // Check normal straight or A-2-3-4-5 straight
    if (weights[4] - weights[0] === 4 && new Set(weights).size === 5) {
        isStraight = true;
    } else if (weights.toString() === '2,3,4,5,14') { // Low Ace straight
        isStraight = true;
    }

    // Count frequencies of values
    const counts = {};
    for (const v of values) {
        counts[v] = (counts[v] || 0) + 1;
    }
    const freq = Object.values(counts).sort((a, b) => b - a);

    // Hand ranking & Payout multipliers
    if (isStraight && isFlush && weights[4] === 14 && weights[0] === 10) return { name: 'Royal Flush', mult: 50 };
    if (isStraight && isFlush) return { name: 'Straight Flush', mult: 20 };
    if (freq[0] === 4) return { name: 'Four of a Kind', mult: 12 };
    if (freq[0] === 3 && freq[1] === 2) return { name: 'Full House', mult: 8 };
    if (isFlush) return { name: 'Flush', mult: 6 };
    if (isStraight) return { name: 'Straight', mult: 4 };
    if (freq[0] === 3) return { name: 'Three of a Kind', mult: 3 };
    if (freq[0] === 2 && freq[1] === 2) return { name: 'Two Pair', mult: 2 };
    if (freq[0] === 2) return { name: 'One Pair (Jacks or Better)', mult: 1 }; // Simplified pair win

    return { name: 'High Card', mult: 0 };
}

module.exports = {
    name: 'poker',
    description: 'Play a quick hand of video poker and test your card skills!',
    categoryHierarchy: ['Economy', 'Casino'],
    data: new SlashCommandBuilder()
        .setName('poker')
        .setDescription('Play a quick hand of video poker and test your card skills!')
        .addIntegerOption(option =>
            option.setName('bet')
                .setDescription('The amount of coins to wager')
                .setRequired(true)
                .setMinValue(10)
                .setMaxValue(10000)
        ),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        const userId = isSlash ? messageOrInteraction.user.id : messageOrInteraction.author.id;
        const userTag = isSlash ? messageOrInteraction.user.tag : messageOrInteraction.author.tag;

        const betAmount = isSlash 
            ? messageOrInteraction.options.getInteger('bet')
            : parseInt(messageOrInteraction.content.split(/\s+/)[1]);

        if (isNaN(betAmount) || betAmount <= 0) {
            const errPayload = { content: '❌ Please specify a valid positive bet amount.', flags: [MessageFlags.Ephemeral] };
            return isSlash ? messageOrInteraction.reply(errPayload) : messageOrInteraction.reply(errPayload);
        }

        // Initialize user balance if not present
        if (!userBalances.has(userId)) {
            userBalances.set(userId, 1000);
        }

        const currentBalance = userBalances.get(userId);
        if (currentBalance < betAmount) {
            const lowBalPayload = { 
                content: `❌ Insufficient funds! You have **${currentBalance}** coins in your balance.`, 
                flags: [MessageFlags.Ephemeral] 
            };
            return isSlash ? messageOrInteraction.reply(lowBalPayload) : messageOrInteraction.reply(lowBalPayload);
        }

        // Deduct wager
        userBalances.set(userId, currentBalance - betAmount);

        // Draw 5 random unique-ish cards
        const hand = [];
        for (let i = 0; i < 5; i++) {
            hand.push(getRandomCard());
        }

        const result = evaluateHand(hand);
        const winnings = Math.floor(betAmount * result.mult);

        if (winnings > 0) {
            userBalances.set(userId, userBalances.get(userId) + winnings);
        }

        const newBalance = userBalances.get(userId);
        const cardDisplay = hand.map(c => `\`[${c.value}${c.suit}]\``).join(' ');

        const pokerEmbed = new EmbedBuilder()
            .setColor(winnings > 0 ? '#57F287' : '#ED4245')
            .setTitle(`🃏 Video Poker — ${result.name}`)
            .setDescription(`Your Hand:\n${cardDisplay}`)
            .addFields(
                { name: 'Wager', value: `🪙 ${betAmount} coins`, inline: true },
                { name: 'Payout', value: `🪙 ${winnings} coins (${result.mult}x)`, inline: true },
                { name: 'New Balance', value: `🪙 ${newBalance} coins`, inline: true }
            )
            .setTimestamp()
            .setFooter({ text: `Player: ${userTag} • The Syndicate V3.2 Economy` });

        await messageOrInteraction.reply({
            embeds: [pokerEmbed],
            flags: isSlash ? [MessageFlags.Ephemeral] : []
        });
    }
};