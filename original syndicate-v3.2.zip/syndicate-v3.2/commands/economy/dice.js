const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

// Shared in-memory balance tracker (synchronized with economy modules)
const userBalances = new Map();

// Dice face emojis for a visual roll experience
const DICE_FACES = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

module.exports = {
    name: 'dice',
    description: 'Roll the dice and test your luck against the Syndicate house!',
    categoryHierarchy: ['Economy', 'Casino'],
    data: new SlashCommandBuilder()
        .setName('dice')
        .setDescription('Roll the dice and test your luck against the Syndicate house!')
        .addIntegerOption(option =>
            option.setName('bet')
                .setDescription('Amount of coins you want to bet')
                .setRequired(true)
                .setMinValue(10)
                .setMaxValue(5000)
        )
        .addIntegerOption(option =>
            option.setName('prediction')
                .setDescription('Predict the dice number (1 to 6)')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(6)
        ),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        const userId = isSlash ? messageOrInteraction.user.id : messageOrInteraction.author.id;
        const userTag = isSlash ? messageOrInteraction.user.tag : messageOrInteraction.author.tag;

        const betAmount = isSlash ? messageOrInteraction.options.getInteger('bet') : 50;
        const userPrediction = isSlash ? messageOrInteraction.options.getInteger('prediction') : 4;

        // Initialize user balance
        if (!userBalances.has(userId)) userBalances.set(userId, 1000);
        let balance = userBalances.get(userId);

        // Check if user has enough coins
        if (balance < betAmount) {
            const lowBalPayload = { 
                content: `❌ You don't have enough coins! Your current balance is **🪙 ${balance} coins**.` , 
                flags: [MessageFlags.Ephemeral] 
            };
            return isSlash ? messageOrInteraction.reply(lowBalPayload) : messageOrInteraction.reply(lowBalPayload);
        }

        // Roll the dice (Random number between 1 and 6)
        const rolledNumber = Math.floor(Math.random() * 6) + 1;
        const diceEmoji = DICE_FACES[rolledNumber - 1];

        let winnings = 0;
        let isWin = false;

        if (rolledNumber === userPrediction) {
            // Exact match gives 5x payout!
            winnings = betAmount * 5;
            balance += winnings - betAmount; // Net gain
            isWin = true;
        } else {
            // Loss
            balance -= betAmount;
            isWin = false;
        }

        userBalances.set(userId, balance);

        // Result Embed
        const diceEmbed = new EmbedBuilder()
            .setColor(isWin ? '#57F287' : '#ED4245')
            .setTitle(`🎲 THE SYNDICATE DICE TABLE`)
            .setDescription(isWin 
                ? `🎉 **JACKPOT!** You predicted the exact roll and won big!` 
                : `💥 **LOST!** The house wins this roll. Better luck next time!`
            )
            .addFields(
                { name: 'Your Prediction', value: `🎯 ${userPrediction}`, inline: true },
                { name: 'Rolled Dice', value: `${diceEmoji} (${rolledNumber})`, inline: true },
                { name: isWin ? 'Payout Won' : 'Coins Lost', value: `🪙 ${isWin ? winnings : betAmount} coins`, inline: true },
                { name: 'New Balance', value: `🪙 ${balance} coins`, inline: false }
            )
            .setTimestamp()
            .setFooter({ text: `Player: ${userTag} • The Syndicate V3.2 Casino` });

        await messageOrInteraction.reply({ embeds: [diceEmbed] });
    }
};