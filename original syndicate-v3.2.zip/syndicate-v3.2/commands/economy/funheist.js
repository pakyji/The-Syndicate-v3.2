const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

// Shared in-memory balance tracker (synchronized with all economy modules)
const userBalances = new Map();

// Cooldown tracker (User ID -> Timestamp)
const heistCooldowns = new Map();
const COOLDOWN_TIME = 60 * 1000; // 60 seconds cooldown

const HEIST_TARGETS = [
    { name: 'Local Credit Union', minPayout: 500, maxPayout: 1500, successRate: 0.55, cost: 200, value: 'creditunion' },
    { name: 'City Central Reserve', minPayout: 1500, maxPayout: 4000, successRate: 0.35, cost: 500, value: 'centralreserve' },
    { name: 'The Syndicate Underground Casino', minPayout: 3000, maxPayout: 8000, successRate: 0.25, cost: 1000, value: 'syndicatecasino' },
    { name: 'El Patron\'s Hidden Island', minPayout: 7000, maxPayout: 20000, successRate: 0.18, cost: 2500, value: 'islandcompound' }
];

module.exports = {
    name: 'funheist',
    description: 'Plan and execute a major underworld heist!',
    categoryHierarchy: ['Economy', 'Casino'],
    data: new SlashCommandBuilder()
        .setName('funheist')
        .setDescription('Plan and execute a major underworld heist!')
        .addStringOption(option =>
            option.setName('target')
                .setDescription('Choose your heist target')
                .setRequired(true)
                .addChoices(
                    { name: 'Local Credit Union (Easy, Low Risk)', value: 'creditunion' },
                    { name: 'City Central Reserve (Medium, High Risk)', value: 'centralreserve' },
                    { name: 'Syndicate Underground Casino (Hard, Extreme Risk)', value: 'syndicatecasino' },
                    { name: 'El Patron\'s Hidden Island (Mastermind, Legendary)', value: 'islandcompound' }
                )
        ),

    async execute(messageOrInteraction, client) {
        const isSlash = messageOrInteraction.isChatInputCommand && messageOrInteraction.isChatInputCommand();
        const userId = isSlash ? messageOrInteraction.user.id : messageOrInteraction.author.id;
        const userTag = isSlash ? messageOrInteraction.user.tag : messageOrInteraction.author.tag;

        const targetChoice = isSlash ? messageOrInteraction.options.getString('target') : 'creditunion';
        
        let targetData = HEIST_TARGETS.find(t => t.value === targetChoice) || HEIST_TARGETS[0];

        // Check Cooldown
        const now = Date.now();
        if (heistCooldowns.has(userId)) {
            const expirationTime = heistCooldowns.get(userId) + COOLDOWN_TIME;
            if (now < expirationTime) {
                const timeLeft = Math.ceil((expirationTime - now) / 1000);
                const cdPayload = { 
                    content: `⏳ Your syndicate crew is still laying low after the last op! Wait **${timeLeft} seconds**.`, 
                    flags: [MessageFlags.Ephemeral] 
                };
                return isSlash ? messageOrInteraction.reply(cdPayload) : messageOrInteraction.reply(cdPayload);
            }
        }
        heistCooldowns.set(userId, now);

        // Initialize user balance
        if (!userBalances.has(userId)) userBalances.set(userId, 1000);
        const currentBalance = userBalances.get(userId);

        // Check setup cost
        if (currentBalance < targetData.cost) {
            const costPayload = { 
                content: `❌ You need at least **🪙 ${targetData.cost} coins** as preparation/intel cost for the **${targetData.name}**!`, 
                flags: [MessageFlags.Ephemeral] 
            };
            return isSlash ? messageOrInteraction.reply(costPayload) : messageOrInteraction.reply(costPayload);
        }

        // Deduct setup cost immediately
        let updatedBalance = currentBalance - targetData.cost;
        userBalances.set(userId, updatedBalance);

        // Roll for success
        const isSuccess = Math.random() < targetData.successRate;
        let payout = 0;
        let title = '';
        let color = '';

        if (isSuccess) {
            payout = Math.floor(Math.random() * (targetData.maxPayout - targetData.minPayout + 1)) + targetData.minPayout;
            updatedBalance += payout;
            userBalances.set(userId, updatedBalance);
            
            title = `💰 UNDERWORLD HEIST SUCCESS: ${targetData.name}!`;
            color = '#57F287'; // Green
        } else {
            title = `🚨 SECURITY AMBUSH: ${targetData.name} Failed!`;
            color = '#ED4245'; // Red
        }

        const heistEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle(title)
            .setDescription(isSuccess 
                ? `Brilliant execution! Your crew successfully cracked the security grid, secured the cash bags, and pulled off a clean getaway!` 
                : `You tripped the silent alarm! Heavy security swarmed the compound before you could crack the final vault door.`
            )
            .addFields(
                { name: 'Target', value: `${targetData.name}`, inline: true },
                { name: isSuccess ? 'Syndicate Cut' : 'Intel Cost Lost', value: `🪙 ${isSuccess ? payout : targetData.cost} coins`, inline: true },
                { name: 'New Balance', value: `🪙 ${updatedBalance} coins`, inline: true }
            )
            .setTimestamp()
            .setFooter({ text: `Criminal Mastermind: ${userTag} • The Syndicate V3.2 Economy` });

        await messageOrInteraction.reply({ embeds: [heistEmbed] });
    }
};