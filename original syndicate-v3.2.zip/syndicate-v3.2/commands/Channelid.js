const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('channelid')
        .setDescription('Get the ID of a specific channel by selecting it or searching its name.')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Select or search the channel you want the ID for')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const targetChannel = interaction.options.getChannel('channel');

        await interaction.reply({
            content: `📌 The ID for channel **${targetChannel.name}** is: \`${targetChannel.id}\``,
            flags: [MessageFlags.Ephemeral]
        });
    },
};