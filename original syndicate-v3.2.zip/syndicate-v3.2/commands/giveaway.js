const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

const TARGET_CHANNEL_ID = '1546252181920022538';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway')
        .setDescription('Starts an interactive giveaway with invite tracking, custom messages, and custom host selection!')
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('The prize being given away (e.g., Nitro, In-game Cash)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Duration of giveaway (e.g., 10s, 1m, 1h)')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('min_invites')
                .setDescription('Minimum invites required to enter (Leave 0 for public giveaway)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('message')
                .setDescription('Custom message or card description to display')
                .setRequired(false))
        .addUserOption(option =>
            option.setName('host')
                .setDescription('Select a user or moderator as the giveaway host')
                .setRequired(false)),

    async execute(interaction) {
        const prize = interaction.options.getString('prize');
        const durationStr = interaction.options.getString('duration');
        const minInvites = interaction.options.getInteger('min_invites') || 0;
        const customMessage = interaction.options.getString('message') || 'Win an exclusive prize in this community giveaway!';
        
        // Host selection: Agar koi user select kiya toh uska mention, warna command chalane wala
        const hostUser = interaction.options.getUser('host') || interaction.user;

        let durationMs = 0;
        const timeValue = parseInt(durationStr);
        if (durationStr.endsWith('s')) durationMs = timeValue * 1000;
        else if (durationStr.endsWith('m')) durationMs = timeValue * 60 * 1000;
        else if (durationStr.endsWith('h')) durationMs = timeValue * 60 * 60 * 1000;
        else {
            return interaction.reply({ content: '❌ Invalid time format! Use numbers followed by s, m, or h (e.g., 30s, 10m, 1h).', flags: [MessageFlags.Ephemeral] });
        }

        const endTime = Date.now() + durationMs;
        const participants = new Set();

        const getEmbed = () => {
            return new EmbedBuilder()
                .setTitle('🎉 GIVEAWAY TIME! 🎉')
                .setDescription(`${customMessage}`)
                .setColor('#00ffcc')
                .addFields(
                    { name: '🎁 Prize', value: `**${prize}**`, inline: false },
                    { name: '👑 Hosted By', value: `${hostUser}`, inline: true },
                    { name: '👥 Participants', value: `\`${participants.size}\``, inline: true },
                    { name: '🔗 Min Invites Required', value: `\`${minInvites > 0 ? minInvites : 'None (Open to all)'}\``, inline: false },
                    { name: '⏳ Ends In', value: `<t:${Math.floor(endTime / 1000)}:R>`, inline: false }
                )
                .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ❤️' })
                .setTimestamp();
        };

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('join_giveaway')
                .setLabel('🎉 Join Giveaway')
                .setStyle(ButtonStyle.Success)
        );

        const targetChannel = await interaction.client.channels.fetch(TARGET_CHANNEL_ID).catch(() => null);
        if (!targetChannel) {
            return interaction.reply({ content: `❌ Target channel (<#${TARGET_CHANNEL_ID}>) could not be found!`, flags: [MessageFlags.Ephemeral] });
        }

        await interaction.reply({ content: `🎉 Giveaway successfully launched in <#${TARGET_CHANNEL_ID}>!`, flags: [MessageFlags.Ephemeral] });
        
        const giveawayMessage = await targetChannel.send({
            embeds: [getEmbed()],
            components: [row]
        });

        const collector = giveawayMessage.createMessageComponentCollector({ time: durationMs });

        collector.on('collect', async i => {
            if (minInvites > 0) {
                try {
                    const guildInvites = await i.guild.invites.fetch();
                    let userInvites = 0;
                    guildInvites.forEach(inv => {
                        if (inv.inviter && inv.inviter.id === i.user.id) {
                            userInvites += inv.uses;
                        }
                    });

                    if (userInvites < minInvites) {
                        return i.reply({
                            content: `❌ You need at least **${minInvites} invites** to join this giveaway! (You currently have ${userInvites}).`,
                            flags: [MessageFlags.Ephemeral]
                        });
                    }
                } catch (err) {
                    console.error('Invite fetch error:', err);
                }
            }

            if (participants.has(i.user.id)) {
                return i.reply({ content: '⚠️ You have already joined this giveaway!', flags: [MessageFlags.Ephemeral] });
            }

            participants.add(i.user.id);
            await i.reply({ content: `✅ You have successfully entered the giveaway for **${prize}**!`, flags: [MessageFlags.Ephemeral] });
            
            await giveawayMessage.edit({ embeds: [getEmbed()] });
        });

        collector.on('end', async () => {
            const endedRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('join_giveaway')
                    .setLabel('🔒 Giveaway Ended')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)
            );

            if (participants.size === 0) {
                await giveawayMessage.edit({
                    embeds: [new EmbedBuilder().setTitle('🎉 GIVEAWAY ENDED').setDescription(`Prize: **${prize}**\n\n❌ No valid participants joined.`).setColor('#ff0000')],
                    components: [endedRow]
                });
                return targetChannel.send(`❌ The giveaway for **${prize}** has ended, but no one participated.`);
            }

            const participantsArray = Array.from(participants);
            const winnerId = participantsArray[Math.floor(Math.random() * participantsArray.length)];

            await giveawayMessage.edit({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('🎉 GIVEAWAY ENDED 🎉')
                        .setDescription(`The giveaway for **${prize}** has concluded!`)
                        .setColor('#ffaa00')
                        .addFields(
                            { name: '🏆 Winner', value: `<@${winnerId}>`, inline: false },
                            { name: '👑 Hosted By', value: `${hostUser}`, inline: true },
                            { name: '👥 Total Entries', value: `\`${participants.size}\``, inline: true }
                        )
                        .setTimestamp()
                ],
                components: [endedRow]
            });

            // Channel send use kiya hai taaki winner ka announcement bilkul saaf dikhe
            await targetChannel.send(`🎊 Congratulations <@${winnerId}>! You won **${prize}**! Please contact staff to claim your prize.`);
        });
    },
};