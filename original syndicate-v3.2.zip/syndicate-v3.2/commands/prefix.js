const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const path = require('../prefix-handler'); 

// 🔑 Restricted exclusively to your Discord User ID
const DEVELOPER_ID = '877175223504478218'; 

const data = new SlashCommandBuilder()
    .setName('setprefix')
    .setDescription('Set a custom prefix (Bot Owner Only)')
    .addStringOption(option =>
        option
            .setName('new_prefix')
            .setDescription('Type your desired prefix (leave blank or type "none" for no prefix)')
            .setRequired(false)
    );

module.exports = {
    data,
    async execute(target, isPrefix) {
        // Determine user ID depending on whether it's a message command or slash command
        let userId = isPrefix ? target.author.id : target.user.id;

        // Security check: Restrict command execution exclusively to the bot developer
        if (userId !== DEVELOPER_ID) {
            const errorMsg = '❌ Aapke paas is command ko use karne ki permission nahi hai! Yeh sirf bot owner ke liye hai.';
            if (isPrefix) {
                return await target.reply(errorMsg);
            } else {
                return await target.reply({ content: errorMsg, ephemeral: true });
            }
        }

        let newPrefix = '';
        let guildId = isPrefix ? target.guild.id : target.guildId;

        // Parse arguments for prefix commands or slash command options
        if (isPrefix) {
            const args = target.content.slice(1).trim().split(/ +/).slice(1);
            newPrefix = args.join(' ').trim();
        } else {
            if (!target.deferred && !target.replied) await target.deferReply();
            newPrefix = target.options.getString('new_prefix') || '';
        }

        // Handle blank or "none" input to clear the prefix
        if (newPrefix.toLowerCase() === 'none' || newPrefix === '') {
            newPrefix = ''; // Blank prefix mode
        }

        // Save the updated guild prefix into the local JSON database
        path.setPrefix(guildId, newPrefix);

        // Build and send confirmation embed
        const embed = new EmbedBuilder()
            .setTitle('⚙️ Prefix Updated Successfully')
            .setDescription(`Naya prefix set ho gaya hai: **${newPrefix === '' ? '(Blank / No Prefix)' : newPrefix}**\nAb commands is tarah use hongi: \`${newPrefix}cayocalc\``)
            .setColor('#3498db')
            .setTimestamp();

        if (isPrefix) {
            await target.reply({ embeds: [embed] });
        } else {
            await target.editReply({ embeds: [embed] });
        }
    }
};
