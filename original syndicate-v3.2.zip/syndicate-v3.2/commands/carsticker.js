const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

const carThemes = [
    { theme: 'JDM / Tuners', car: 'Karin S95 / Elegy Retro Custom', image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1200&q=80' },
    { theme: 'Supercars & Hypercars', car: 'Progen Emerus / Pegassi Krieger', image: 'https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?auto=format&fit=crop&w=1200&q=80' },
    { theme: 'Classic / Vintage Legends', car: 'Grotti Turismo Classic / Benefactor Stirling GT', image: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=1200&q=80' },
    { theme: 'Muscle Cars', car: 'Declasse Vigero ZX / Bravado Gauntlet Hellfire', image: 'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?auto=format&fit=crop&w=1200&q=80' },
    { theme: 'Off-Road & Rally Monsters', car: 'Vapid Trophy Truck / Karin Boor', image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1200&q=80' },
    { theme: 'Drift & Track Builds', car: 'Annis Remus / Fathom FR36', image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80' }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('carticker')
        .setDescription('Starts a live auto-updating car theme ticker that changes every 5 seconds!'),

    async execute(interaction) {
        await interaction.reply({
            content: '🏎️ Starting the fast 5-second live vehicle theme ticker...',
            flags: [MessageFlags.Ephemeral]
        });

        let currentIndex = 0;

        const generateEmbed = (index) => {
            const current = carThemes[index];
            return new EmbedBuilder()
                .setTitle('🔄 LOS SANTOS LIVE VEHICLE TICKER')
                .setDescription(`*This display automatically updates every 5 seconds with fresh car meets and vehicle themes across Los Santos!*`)
                .setColor('#2b2d31')
                .addFields(
                    { name: '🎨 Active Theme', value: `\`${current.theme}\``, inline: true },
                    { name: '🚗 Featured Vehicle', value: `\`${current.car}\``, inline: true },
                    { name: '⚡ Status', value: '`TURBO LIVE ROTATION`', inline: false }
                )
                .setImage(current.image)
                .setFooter({ text: 'The Syndicate Staff Team • From The Syndicate core - made with ♥️' })
                .setTimestamp();
        };

        const tickerMessage = await interaction.channel.send({
            embeds: [generateEmbed(currentIndex)]
        });

        const intervalId = setInterval(async () => {
            try {
                currentIndex = (currentIndex + 1) % carThemes.length;
                await tickerMessage.edit({
                    embeds: [generateEmbed(currentIndex)]
                });
            } catch (error) {
                clearInterval(intervalId);
            }
        }, 5000); // 5,000 milliseconds = 5 seconds
    },
};