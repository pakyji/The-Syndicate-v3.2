const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');

const warningsFilePath = path.join(__dirname, '../warnings.json');
const TIMEOUT_REPORT_CHANNEL_ID = '899366913086455828';
const MAX_WARNINGS_BEFORE_TIMEOUT = 5;
const TIMEOUT_DURATION_MS = 10 * 60 * 1000; // 10 Minutes timeout (Aap ise change bhi kar sakte hain)

function loadWarnings() {
    try {
        if (!fs.existsSync(warningsFilePath)) {
            fs.writeFileSync(warningsFilePath, JSON.stringify({}, null, 2));
        }
        const data = fs.readFileSync(warningsFilePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading warnings.json:', error);
        return {};
    }
}

function saveWarnings(data) {
    try {
        fs.writeFileSync(warningsFilePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Error saving warnings.json:', error);
    }
}

/**
 * Adds a warning to a user and checks if timeout action is required.
 * @param {import('discord.js').Guild} guild 
 * @param {import('discord.js').User} user 
 * @param {string} reason 
 */
async function addAndCheckWarning(guild, user, reason = 'No reason provided') {
    if (!guild || !user) return 0;

    const db = loadWarnings();
    const guildId = guild.id;
    const userId = user.id;

    if (!db[guildId]) {
        db[guildId] = {};
    }
    if (!db[guildId][userId]) {
        db[guildId][userId] = [];
    }

    // Add new warning
    db[guildId][userId].push({
        reason,
        timestamp: Date.now()
    });

    const currentWarningsCount = db[guildId][userId].length;
    saveWarnings(db);

    // Check if warnings reach the threshold (5 warnings)
    if (currentWarningsCount >= MAX_WARNINGS_BEFORE_TIMEOUT) {
        try {
            const member = await guild.members.fetch(userId).catch(() => null);
            if (member && member.moderatable) {
                // Apply Timeout
                await member.timeout(TIMEOUT_DURATION_MS, `Reached ${currentWarningsCount} warnings limit.`);

                // Send Report Embed to the specific channel
                const reportChannel = await guild.channels.fetch(TIMEOUT_REPORT_CHANNEL_ID).catch(() => null);
                if (reportChannel) {
                    const reportEmbed = new EmbedBuilder()
                        .setColor('#FFA500')
                        .setTitle('🚨 Automatic Timeout Issued')
                        .setDescription(`A user has reached the maximum warning limit and has been timed out automatically.`)
                        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                        .addFields(
                            { name: '👤 User', value: `${user.tag} (\`${user.id}\`)`, inline: false },
                            { name: '⚠️ Total Warnings', value: `${currentWarningsCount} Warnings`, inline: true },
                            { name: '⏳ Timeout Duration', value: '10 Minutes', inline: true },
                            { name: '📌 Latest Violation Reason', value: `\`\`\`${reason}\`\`\``, inline: false }
                        )
                        .setTimestamp()
                        .setFooter({ text: 'The Syndicate Security & Moderation System' });

                    await reportChannel.send({ embeds: [reportEmbed] });
                }
            }
        } catch (err) {
            console.error('Error applying automatic timeout or sending report:', err);
        }
    }

    return currentWarningsCount;
}

function getWarnings(guildId, userId) {
    const db = loadWarnings();
    if (!db[guildId] || !db[guildId][userId]) return [];
    return db[guildId][userId];
}

function clearWarnings(guildId, userId) {
    const db = loadWarnings();
    if (db[guildId] && db[guildId][userId]) {
        delete db[guildId][userId];
        saveWarnings(db);
        return true;
    }
    return false;
}

module.exports = { addAndCheckWarning, getWarnings, clearWarnings };