require('dotenv').config();

module.exports = {
    token: process.env.DISCORD_TOKEN,
    geminiKey: process.env.GEMINI_API_KEY,
    openaiKey: process.env.OPENAI_API_KEY,
    guildId: process.env.GUILD_ID,
    ownerId: process.env.OWNER_ID,
    clientId: process.env.CLIENT_ID,
    prefix: process.env.PREFIX || '.',
};
