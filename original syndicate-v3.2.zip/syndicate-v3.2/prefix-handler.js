const fs = require('fs');
const filePath = './prefixes.json';

// Load prefixes from the local JSON database file
function loadPrefixes() {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify({}));
    }
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (e) {
        return {};
    }
}

// Retrieve custom prefix for a specific guild (defaults to '.' if not configured)
function getPrefix(guildId) {
    const prefixes = loadPrefixes();
    return prefixes[guildId] !== undefined ? prefixes[guildId] : '.'; 
}

// Save or update custom prefix for a specific guild into the JSON file
function setPrefix(guildId, prefix) {
    const prefixes = loadPrefixes();
    prefixes[guildId] = prefix;
    fs.writeFileSync(filePath, JSON.stringify(prefixes, null, 2));
}

module.exports = { getPrefix, setPrefix };