require('dotenv').config();

// Global crash protection handlers
process.on('unhandledRejection', error => {
    console.error('❌ Unhandled promise rejection:', error);
});

process.on('uncaughtException', error => {
    console.error('❌ Uncaught exception:', error);
});

const {
    Client,
    GatewayIntentBits,
    Collection,
    EmbedBuilder,
    REST,
    Routes,
    MessageFlags,
    Events
} = require('discord.js');

const { getPrefix } = require('./prefix-handler');
const { ensureSupportPanel, handleSupportInteractions } = require('./handlers/supportSystem');
const { ensureVerificationPanel, setupWelcome, handleVerificationInteractions } = require('./handlers/verificationFlow');

// Moderation modules imports
const { handleAntiLink } = require('./handlers/antilink');
const { handleAntiBadWords } = require('./handlers/antibadwords');
const { handleAntiSpam } = require('./handlers/antispam');

// Quote module import
const quoteModule = require('./commands/quote'); 

// Auto-Greetings module import
const { startAutoGreetings } = require('./handlers/greetings');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates 
    ]
});

client.commands = new Collection();

// Load commands via handler
require('./handlers/commandhandler')(client);

const AUTO_NEWS_CHANNEL_ID = '1534889391590215781'; 

const RSS_FEED_URLS = [
    'https://www.rockstargames.com/newswire/feed',
    'https://rockstarintel.com/category/gta-online/event-week/feed/'
];

const sentLinks = new Set();
let isMaskingEnabled = false;

function parseSimpleXML(xmlText) {
    const items = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;

    while ((match = itemRegex.exec(xmlText)) !== null) {
        const itemContent = match[1];
        
        const titleMatch = itemContent.match(/<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?<\/title>/);
        const title = titleMatch ? titleMatch[1].trim() : 'No Title';

        const linkMatch = itemContent.match(/<link>(.*?)<\/link>/);
        const link = linkMatch ? linkMatch[1].trim() : '';

        if (link) items.push({ title, link });
    }
    return items;
}

async function updateServerStats(guild) {
    if (!client.statsChannels || !client.statsChannels[guild.id]) return;
    const channels = client.statsChannels[guild.id];

    try {
        await guild.members.fetch();
        const total = guild.memberCount;
        const bots = guild.members.cache.filter(m => m.user.bot).size;
        const humans = total - bots;

        const allChan = guild.channels.cache.get(channels.all);
        const memChan = guild.channels.cache.get(channels.members);
        const botChan = guild.channels.cache.get(channels.bots);

        if (allChan) await allChan.setName(`👥 All Members: ${total}`);
        if (memChan) await memChan.setName(`👤 Members: ${humans}`);
        if (botChan) await botChan.setName(`🤖 Bots: ${bots}`);
    } catch (e) {
        console.error('❌ Stats update karne mein error aa gaya:', e);
    }
}

client.on(Events.GuildMemberAdd, member => {
    updateServerStats(member.guild);
});

client.on(Events.GuildMemberRemove, member => {
    updateServerStats(member.guild);
});

client.once('ready', async () => {
    console.log(`The Syndicate V 3.2 is active now (${client.user.tag})`);

    setupWelcome(client);
    await ensureVerificationPanel(client);
    await ensureSupportPanel(client);

    if (quoteModule && typeof quoteModule.startHourlyQuotes === 'function') {
        quoteModule.startHourlyQuotes(client);
        console.log('✅ 30-Minute quotes background loop started successfully!');
    }

    startAutoGreetings(client);
    console.log('✅ Auto-Greetings background loop started successfully!');

    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    try {
        console.log('🔄 Started refreshing application (/) commands...');
        const commandData = client.commands.map(cmd => cmd.data.toJSON());
        
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commandData },
        );
        console.log('✅ Successfully reloaded application (/) commands globally!');
    } catch (error) {
        console.error('❌ Error registering slash commands:', error);
    }

    setInterval(async () => {
        const channel = await client.channels.fetch(AUTO_NEWS_CHANNEL_ID).catch(() => null);
        if (!channel) return;

        for (const feedUrl of RSS_FEED_URLS) {
            try {
                const response = await fetch(feedUrl);
                const xmlText = await response.text();
                const items = parseSimpleXML(xmlText);

                if (items.length === 0) continue;

                const latestItem = items[0];

                if (!sentLinks.has(latestItem.link)) {
                    sentLinks.add(latestItem.link);

                    if (sentLinks.size > 100) {
                        const firstItem = sentLinks.values().next().value;
                        sentLinks.delete(firstItem);
                    }

                    const embed = new EmbedBuilder()
                        .setTitle('🚨 New GTA / Rockstar Update!')
                        .setDescription(`**[${latestItem.title}](${latestItem.link})**`)
                        .setColor('#f39c12')
                        .setTimestamp()
                        .setFooter({ text: 'Auto-News Multi-Feed Tracker' });

                    await channel.send({ embeds: [embed] });
                }
            } catch (error) {
                console.error(`❌ Error fetching feed ${feedUrl}:`, error);
            }
        }
    }, 3600000);
});

client.on('interactionCreate', async interaction => {
    if (
        interaction.customId === 'start_verify' ||
        interaction.customId === 'select_platform_type' ||
        (interaction.customId && interaction.customId.startsWith('gamertag_modal_'))
    ) {
        await handleVerificationInteractions(interaction);
        return;
    }

    if (
        interaction.customId === 'sup_start' ||
        interaction.customId === 'sup_select_activity' ||
        (interaction.customId && interaction.customId.startsWith('sup_select_platform_')) ||
        (interaction.customId && interaction.customId.startsWith('sup_modal_'))
    ) {
        await handleSupportInteractions(interaction);
        return;
    }

    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction, client);
        } catch (error) {
            console.error(error);
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: '❌ Error aa gaya hai.', flags: [MessageFlags.Ephemeral] });
            }
        }
        return;
    }

    if (interaction.isButton()) {
        try {
            if (interaction.customId && interaction.customId.startsWith('calc_')) {
                return; 
            }

            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: '⚙️ Button click received!', flags: [MessageFlags.Ephemeral] });
            }
        } catch (error) {
            console.error('❌ Button Interaction Error:', error);
        }
        return;
    }
});

client.on('messageCreate', async message => {
    if (!message.guild) return;

    // 🛡️ Moderation Checks (No bypass for anyone)
    const linkTriggered = await handleAntiLink(message);
    if (linkTriggered || message.deleted) return;

    const badWordTriggered = await handleAntiBadWords(message);
    if (badWordTriggered || message.deleted) return;

    const spamTriggered = await handleAntiSpam(message);
    if (spamTriggered || message.deleted) return;

    const adminMaskUserId = '877175223504478218';
    const currentPrefix = getPrefix(message.guild.id);

    if (message.author.id === adminMaskUserId && message.content.startsWith(currentPrefix + 'mask')) {
        const args = message.content.slice(currentPrefix.length + 4).trim().toLowerCase();
        
        if (args === 'on') {
            isMaskingEnabled = true;
            await message.reply('✅ Webhook message masking is now **ENABLED**.');
        } else if (args === 'off') {
            isMaskingEnabled = false;
            await message.reply('❌ Webhook message masking is now **DISABLED**.');
        } else {
            await message.reply(`ℹ️ Current status: **${isMaskingEnabled ? 'ON' : 'OFF'}**.`);
        }
        return;
    }

    if (message.author.bot) return;

    if (isMaskingEnabled && message.author.id === adminMaskUserId) {
        if (message.webhookId) return;

        const textToSend = message.content;
        const attachments = message.attachments.map(att => att.url);

        if (textToSend || attachments.length > 0) {
            try {
                await message.delete().catch(() => {});

                const webhooks = await message.channel.fetchWebhooks();
                let webhook = webhooks.find(wh => wh.owner.id === client.user.id);

                if (!webhook) {
                    webhook = await message.channel.createWebhook({
                        name: client.user.username,
                        avatar: client.user.displayAvatarURL(),
                    });
                }

                await webhook.send({
                    content: textToSend || undefined,
                    files: attachments.length > 0 ? attachments : undefined,
                    username: client.user.username,
                    avatarURL: client.user.displayAvatarURL(),
                });
            } catch (error) {
                console.error('Auto-Masking Webhook Error:', error);
            }
            return; 
        }
    }

    const targetUserId = '877175223504478218';
    if (message.mentions.has(client.user) || message.mentions.has(targetUserId)) {
        const query = message.content
            .replace(new RegExp(`<@!?${client.user.id}>`, 'g'), '')
            .replace(new RegExp(`<@!?${targetUserId}>`, 'g'), '')
            .trim();

        if (!query) {
            await message.reply('Haan bhai, bolo kya help chahiye? 🤖');
            return;
        }

        try {
            await message.channel.sendTyping();
            const prompt = `Answer in English: ${query}`;
            const response = await fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}`);
            const replyText = await response.text();

            if (replyText && replyText.trim().length > 0) {
                await message.reply(replyText.trim());
            } else {
                await message.reply('Bhai, iska jawab samajh nahi aaya!');
            }
        } catch (error) {
            console.error('AI Chat Error:', error);
        }
        return;
    }

    const targetChannelId = '1538595475794563167';
    if (message.channel.id === targetChannelId) {
        const textToTranslate = message.content;
        if (!textToTranslate) return;

        let translatedText = textToTranslate;
        try {
            const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(textToTranslate)}&langpair=autodetect|en`;
            const response = await fetch(url);
            const data = await response.json();
            if (data && data.responseStatus === 200 && data.responseData.translatedText) {
                translatedText = data.responseData.translatedText;
            }
        } catch (error) {
            console.error('Fast Translation Notice:', error.message);
        }

        const embed = new EmbedBuilder()
            .setColor('#5865F2')
            .setAuthor({ name: message.author.globalName || message.author.username })
            .setDescription(translatedText)
            .setTimestamp()
            .setFooter({ text: '⚡ Auto-Translated to English' });

        try {
            await message.delete().catch(() => {});
            await message.channel.send({ embeds: [embed] });
        } catch (err) {
            console.error('Message Send/Delete Error:', err);
        }
        return; 
    }

    let commandName = '';
    if (currentPrefix !== '' && message.content.startsWith(currentPrefix)) {
        const args = message.content.slice(currentPrefix.length).trim().split(/ +/);
        commandName = args.shift().toLowerCase();
    } else if (currentPrefix === '') {
        const args = message.content.trim().split(/ +/);
        commandName = args.shift().toLowerCase();
    } else {
        return;
    }

    const command = client.commands.get(commandName);
    if (!command) return;

    try {
        await command.execute(message, true);
    } catch(error) {
        console.error(error);
        await message.reply('❌ Command execute karte waqt error aa gaya hai.');
    }
});

client.login(process.env.DISCORD_TOKEN);