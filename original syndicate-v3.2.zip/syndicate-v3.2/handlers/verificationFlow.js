const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    StringSelectMenuBuilder, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    Events 
} = require('discord.js');

// Configuration IDs provided
const VERIFY_CHANNEL_ID = '1536212551518650402';
const WELCOME_CHANNEL_ID = '901709300383227934';
const GENERAL_CHAT_ID = '901685831943733268';
const PS4_CHANNEL_ID = '901702088738865172';
const PS5_CHANNEL_ID = '1550856575495839824';
const PC_CHANNEL_ID = '1535658134230671370';
const VERIFIED_ROLE_ID = '1536212550360764457';

// 1. Ensure permanent Verification Panel exists in the verification channel
async function ensureVerificationPanel(client) {
    try {
        const channel = await client.channels.fetch(VERIFY_CHANNEL_ID).catch(() => null);
        if (!channel) return;

        const messages = await channel.messages.fetch({ limit: 10 });
        const existingPanel = messages.find(m => m.author.id === client.user.id && m.components.length > 0);

        if (!existingPanel) {
            const embed = new EmbedBuilder()
                .setTitle('🛡️ THE SYNDICATE - Verification')
                .setDescription('Click the **Verify** button below to verify your account and select your platform/gamertag! 🚀')
                .setColor('#2ecc71')
                .setFooter({ text: 'The Syndicate Security System' });

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('start_verify')
                    .setLabel('Verify')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('✅')
            );

            await channel.send({ embeds: [embed], components: [row] });
            console.log('✅ Verification panel created successfully!');
        }
    } catch (error) {
        console.error('❌ Error creating verification panel:', error);
    }
}

// 2. Welcome Message Handler
function setupWelcome(client) {
    client.on(Events.GuildMemberAdd, async member => {
        try {
            const channel = member.guild.channels.cache.get(WELCOME_CHANNEL_ID);
            if (!channel) return;

            const welcomeMessage = 
                `Welcome 👏 <@${member.id}> to THE SYNDICATE 🔥 🔥\n` +
                `Glad to have you here,\n` +
                `Please be verify in <#${VERIFY_CHANNEL_ID}>\n` +
                `You've officially joined the crew. 🤝\n` +
                `🎮 GTA Online — PS4 | PS5 | PC\n` +
                `💲 Missions • Heists • Money Making • Grinding\n` +
                `🤝 Find players • Team up • Have fun\n` +
                `📢 Stay tuned for events, updates & announcements!\n` +
                `📜 Make sure to check the server rules and grab your roles.\n` +
                `Welcome to the family. Welcome to The Syndicate. 🥷💀\n` +
                `Have fun, stay active, and let's build the crew together! 🚀`;

            await channel.send({ content: welcomeMessage });
        } catch (error) {
            console.error('❌ Welcome Message Error:', error);
        }
    });
}

// 3. Handle Verification and Platform Selection Interactions
async function handleVerificationInteractions(interaction) {
    try {
        // Step A: User clicks "Verify" button
        if (interaction.isButton() && interaction.customId === 'start_verify') {
            const member = interaction.member;
            const role = interaction.guild.roles.cache.get(VERIFIED_ROLE_ID);

            if (!role) {
                return interaction.reply({ content: '❌ Verified role is not configured properly.', ephemeral: true });
            }

            // Give role if they don't have it yet
            if (!member.roles.cache.has(VERIFIED_ROLE_ID)) {
                await member.roles.add(role).catch(err => console.error('Role add error:', err));
            }

            // Prompt them to choose their platform right there in the verification channel
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('select_platform_type')
                .setPlaceholder('Choose your platform or status...')
                .addOptions([
                    { label: 'PlayStation 4 (PS4)', value: 'plat_ps4', emoji: '🎮' },
                    { label: 'PlayStation 5 (PS5)', value: 'plat_ps5', emoji: '🎮' },
                    { label: 'PC', value: 'plat_pc', emoji: '💻' },
                    { label: 'Mobile User / Non-Gamer', value: 'plat_mobile', emoji: '📱' }
                ]);

            const row = new ActionRowBuilder().addComponents(selectMenu);

            return interaction.reply({
                content: '🎉 **You are verified!** Now, please select your gaming platform or choose Mobile User below:',
                components: [row],
                ephemeral: true
            });
        }

        // Step B: User selects their platform from dropdown
        if (interaction.isStringSelectMenu() && interaction.customId === 'select_platform_type') {
            const choice = interaction.values[0];

            // If Mobile User, redirect to general-chat and finish
            if (choice === 'plat_mobile') {
                return interaction.update({
                    content: `✅ **Verification Complete!** Since you are a mobile user, you can head straight over to <#${GENERAL_CHAT_ID}>. Welcome to the crew! 🚀`,
                    components: []
                });
            }

            // If they picked a gaming platform, open a modal to ask for their Gamertag ID
            const platformNameMap = {
                'plat_ps4': 'PS4',
                'plat_ps5': 'PS5',
                'plat_pc': 'PC'
            };

            const selectedPlatform = platformNameMap[choice];

            const modal = new ModalBuilder()
                .setCustomId(`gamertag_modal_${choice}`)
                .setTitle(`Enter your ${selectedPlatform} Gamertag`);

            const gamertagInput = new TextInputBuilder()
                .setCustomId('gamertag_input')
                .setLabel(`Your ${selectedPlatform} ID / Username`)
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('e.g. SyndicateKing99')
                .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(gamertagInput));
            return interaction.showModal(modal);
        }

        // Step C: Modal Submission -> Post to respective platform channel
        if (interaction.isModalSubmit() && interaction.customId.startsWith('gamertag_modal_')) {
            const choice = interaction.customId.replace('gamertag_modal_', '');
            const gamertag = interaction.fields.getTextInputValue('gamertag_input');
            const member = interaction.member;

            const targetChannels = {
                'plat_ps4': PS4_CHANNEL_ID,
                'plat_ps5': PS5_CHANNEL_ID,
                'plat_pc': PC_CHANNEL_ID
            };

            const platformTitles = {
                'plat_ps4': 'PlayStation 4 (PS4)',
                'plat_ps5': 'PlayStation 5 (PS5)',
                'plat_pc': 'PC'
            };

            const destChannelId = targetChannels[choice];
            const channel = interaction.guild.channels.cache.get(destChannelId);

            if (channel) {
                const embed = new EmbedBuilder()
                    .setTitle('🎮 New Member Gamertag Registered!')
                    .setColor('#3498db')
                    .addFields(
                        { name: 'User', value: `<@${member.id}>`, inline: true },
                        { name: 'Platform', value: platformTitles[choice], inline: true },
                        { name: 'Gamertag ID', value: `\`${gamertag}\``, inline: false }
                    )
                    .setTimestamp()
                    .setFooter({ text: 'The Syndicate Verification System' });

                await channel.send({ embeds: [embed] });
            }

            return interaction.reply({
                content: `✅ Success! Your **${platformTitles[choice]}** ID (\`${gamertag}\`) has been shared in <#${destChannelId}>. Welcome aboard! 🚀`,
                ephemeral: true
            });
        }

    } catch (error) {
        console.error('❌ Verification Interaction Error:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: '❌ An error occurred while processing your request.', ephemeral: true }).catch(() => {});
        }
    }
}

module.exports = { 
    ensureVerificationPanel, 
    setupWelcome, 
    handleVerificationInteractions 
};