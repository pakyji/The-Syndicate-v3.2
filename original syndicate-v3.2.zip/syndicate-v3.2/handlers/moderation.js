const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');

// Bad words file load karna
const badWordsPath = path.join(__dirname, '../badwords.json');

function getBadWords() {
    try {
        if (!fs.existsSync(badWordsPath)) return [];
        const data = fs.readFileSync(badWordsPath, 'utf8');
        const json = JSON.parse(data);
        return json.words || [];
    } catch (error) {
        console.error('Error reading badwords.json:', error);
        return [];
    }
}

// Parola add karne ke liye function
function addBadWord(word) {
    try {
        const data = fs.readFileSync(badWordsPath, 'utf8');
        const json = JSON.parse(data);
        const lowerWord = word.toLowerCase();

        if (json.words.includes(lowerWord)) {
            return false; // Already exists
        }

        json.words.push(lowerWord);
        fs.writeFileSync(badWordsPath, JSON.stringify(json, null, 4), 'utf8');
        return true;
    } catch (error) {
        console.error('Error adding bad word:', error);
        return false;
    }
}

// Smart Normalizer aur Regex Check
async function handleModeration(message) {
    if (message.author.bot || !message.guild) return;

    // Admin ya Manage Messages wale bypass honge
    if (message.member && (
        message.member.permissions.has('Administrator') || 
        message.member.permissions.has('ManageMessages')
    )) {
        return;
    }

    const badWords = getBadWords();
    if (badWords.length === 0) return;

    // Message ko normalize karna (spaces aur common symbols remove karna taaki bypass na ho sake)
    const rawContent = message.content.toLowerCase();
    const cleanContent = rawContent
        .replace(/[\s\-_.,*+?^${}()|[\]\\]/g, '') // Saare spaces aur symbols hata dega
        .replace(/3/g, 'e')
        .replace(/4/g, 'a')
        .replace(/1/g, 'i')
        .replace(/0/g, 'o')
        .replace(/5/g, 's');

    let matched = false;

    for (const word of badWords) {
        const lowerWord = word.toLowerCase();
        // Exact match ya cleaned content mein match check karna
        if (rawContent.includes(lowerWord) || cleanContent.includes(lowerWord.replace(/[\s\-_]/g, ''))) {
            matched = true;
            break;
        }
    }

    if (matched) {
        try {
            // 1. Message delete karein
            await message.delete();

            // 2. User ko DM bhejein
            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('⚠️ Warning: Bad Word Detected')
                    .setDescription(`Aapka message ${message.guild.name} mein delete kar diya gaya hai kyunki usme forbidden word tha.`);
                await message.author.send({ embeds: [dmEmbed] });
            } catch (dmError) {
                // Agar user ka DM band ho toh ignore karein
            }

            // 3. Channel par temporary warning alert
            const alertMessage = await message.channel.send({
                content: `⚠️ ${message.author}, yahan bad words use karna mana hai! Yeh message delete kar diya gaya hai.`
            });

            setTimeout(async () => {
                try {
                    await alertMessage.delete();
                } catch (e) {}
            }, 5000);

        } catch (error) {
            console.error('Moderation error:', error);
        }
    }
}

module.exports = {
    handleModeration,
    addBadWord
};