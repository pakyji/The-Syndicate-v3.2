const { EmbedBuilder } = require('discord.js');

// Channel IDs
const ENGLISH_CHANNEL_ID = '901685831943733268';
const ITALIAN_CHANNEL_ID = '1537221793922940928';

function startAutoGreetings(client) {
    // Greetings schedule for both languages (24-hour format)
    const greetingsSchedule = [
        { 
            hour: 6, minute: 0, 
            english: '🌅 Good morning everyone! Wake up and seize the day! ☕',
            italian: '🌅 Buongiorno a tutti! Svegliatevi e cogliete la giornata! ☕'
        },
        { 
            hour: 12, minute: 0, 
            english: '☀️ Good afternoon! Hope your day is going awesome so far! 🚀',
            italian: '☀️ Buon pomeriggio! Spero che la vostra giornata stia andando alla grande! 🚀'
        },
        { 
            hour: 18, minute: 0, 
            english: '🌆 Good evening! Time to wrap up things or chill out! 🎮',
            italian: '🌆 Buonasera! È ora di concludere le cose o rilassarsi! 🎮'
        },
        { 
            hour: 23, minute: 0, 
            english: '🌙 Good night everyone! Sweet dreams and take care! 💤',
            italian: '🌙 Buonanotte a tutti! Sogni d\'oro e abbiate cura di voi! 💤'
        }
    ];

    let lastSentKey = '';

    setInterval(async () => {
        try {
            const now = new Date();
            const currentHour = now.getHours();
            const currentMinute = now.getMinutes();
            const currentDateKey = `${now.toDateString()}-${currentHour}-${currentMinute}`;

            const matchedGreeting = greetingsSchedule.find(
                g => g.hour === currentHour && g.minute === currentMinute
            );

            if (matchedGreeting && lastSentKey !== currentDateKey) {
                lastSentKey = currentDateKey;

                // 1. Send English Greeting to English Channel
                const englishChannel = await client.channels.fetch(ENGLISH_CHANNEL_ID).catch(() => null);
                if (englishChannel) {
                    const engEmbed = new EmbedBuilder()
                        .setColor('#0099ff')
                        .setDescription(matchedGreeting.english)
                        .setTimestamp();
                    await englishChannel.send({ embeds: [engEmbed] });
                }

                // 2. Send Italian Greeting to Italian Channel
                const italianChannel = await client.channels.fetch(ITALIAN_CHANNEL_ID).catch(() => null);
                if (italianChannel) {
                    const itaEmbed = new EmbedBuilder()
                        .setColor('#0099ff')
                        .setDescription(matchedGreeting.italian)
                        .setTimestamp();
                    await italianChannel.send({ embeds: [itaEmbed] });
                }

                console.log(`✅ Multi-language auto-greetings sent successfully for ${currentHour}:${currentMinute}`);
            }
        } catch (error) {
            console.error('❌ Auto-Greetings Error:', error);
        }
    }, 60000); // Check every 1 minute
}

module.exports = { startAutoGreetings };