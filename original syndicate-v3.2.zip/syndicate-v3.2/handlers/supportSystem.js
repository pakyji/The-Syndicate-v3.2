const { ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

const GTA_SUPPORT_CHANNEL_ID = '1535656533919014932'; // Canale principale #sos ‧ gta-support
const ITALIAN_SUPPORT_CHANNEL_ID = '1537221793922940928'; // Canale italiano

async function ensureSupportPanel(client) {
    const channelsToSetup = [
        { id: GTA_SUPPORT_CHANNEL_ID, lang: 'en' },
        { id: ITALIAN_SUPPORT_CHANNEL_ID, lang: 'it' }
    ];

    for (const item of channelsToSetup) {
        try {
            const channel = await client.channels.fetch(item.id).catch(() => null);
            if (!channel) continue;

            const messages = await channel.messages.fetch({ limit: 10 }).catch(() => null);
            if (messages) {
                const existingPanel = messages.find(m => m.author.id === client.user.id && m.embeds && m.embeds[0]?.title?.includes('SUPPORT'));
                if (existingPanel) {
                    try {
                        const pinnedMessages = await channel.messages.fetchPins().catch(() => null);
                        const isPinned = pinnedMessages ? pinnedMessages.some(m => m.id === existingPanel.id) : false;
                        if (!isPinned) {
                            await existingPanel.pin().catch(() => {});
                        }
                    } catch (e) {
                        // Ignora eventuali errori di pin
                    }
                    continue;
                }
            }

            let embed;
            if (item.lang === 'it') {
                embed = new EmbedBuilder()
                    .setTitle('🛡️ THE SYNDICATE V — GTA V — SUPPORTO E ASSISTENZA')
                    .setDescription(
                        '**Hai bisogno di aiuto, supporto per le Heist o vuoi organizzare una sessione?**\n\n' +
                        'Usa il nostro sistema interattivo per selezionare la tua attività e inviare subito un alert LFG.\n\n' +
                        '📌 **Clicca il pulsante qui sotto per iniziare!**'
                    )
                    .setColor('#2b2d31')
                    .setImage('https://i.imgur.com/Ie4j48r.jpeg')
                    .setFooter({ text: 'The Syndicate V • Staff Support Desk (Italian)' })
                    .setTimestamp();
            } else {
                embed = new EmbedBuilder()
                    .setTitle('🛡️ THE SYNDICATE V — GTA V — SUPPORT & LFG DESK')
                    .setDescription(
                        '**Need heist support, crew members, or want to organize a session?**\n\n' +
                        'Our interactive LFG & support system guides you to pick your exact activity instantly.\n\n' +
                        '📌 **Click the button below to get started!**'
                    )
                    .setColor('#2b2d31')
                    .setImage('https://i.imgur.com/Ie4j48r.jpeg')
                    .setFooter({ text: 'The Syndicate V • Staff Support Desk' })
                    .setTimestamp();
            }

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('sup_start')
                    .setLabel('SOS Gta Support/Request Help')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🚨')
            );

            const sentPanel = await channel.send({ embeds: [embed], components: [row] });
            await sentPanel.pin().catch(() => {});

        } catch (err) {
            console.error(`❌ Errore nel setup del pannello nel canale ${item.id}:`, err);
        }
    }
}

async function handleSupportInteractions(interaction) {
    try {
        // Step 1: Click sul bottone SOS -> Mostra la lista delle attività
        if (interaction.customId === 'sup_start') {
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

            const activityRow = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('sup_select_activity')
                    .setPlaceholder('Step 1 — Select Heist / Activity / Service...')
                    .addOptions([
                        { label: 'Apartment All Heists + Setups', value: 'Apartment Heists + Setups', emoji: '🏠' },
                        { label: 'Cayo Perico Heist', value: 'Cayo Perico Heist', emoji: '🏝️' },
                        { label: 'Diamond Casino Heist', value: 'Diamond Casino Heist', emoji: '🎰' },
                        { label: 'Dr. Dre Contract (VIP Contract)', value: 'Dr. Dre Contract', emoji: '🎧' },
                        { label: 'Auto Shop Contracts', value: 'Auto Shop Contracts', emoji: '🚗' },
                        { label: 'Bunker Sales & Research', value: 'Bunker Sales & Research', emoji: '📦' },
                        { label: 'MC Businesses / Nightclub / Cargo', value: 'MC & Businesses Cargo', emoji: '📈' },
                        { label: 'Missions / Setup Help / Heist Crew', value: 'Missions & Crew Help', emoji: '👥' },
                        { label: 'Money / Trading / B2B Sessions', value: 'Money & B2B Sessions', emoji: '💰' },
                        { label: 'Vehicles / Car Meets / Glitches / Other', value: 'Vehicles, Glitches & Other', emoji: '⚡' }
                    ])
            );

            return await interaction.editReply({
                content: '**🚨 Syndicate LFG & Support Desk**\nSelect the activity or service you want to organize or need help with:',
                components: [activityRow]
            });
        }

        // Step 2: Attività selezionata -> Seleziona la Piattaforma
        if (interaction.isStringSelectMenu() && interaction.customId === 'sup_select_activity') {
            await interaction.deferUpdate();
            const activity = interaction.values[0];

            const platformRow = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId(`sup_select_platform_${encodeURIComponent(activity)}`)
                    .setPlaceholder('Step 2 — Select your Gaming Platform...')
                    .addOptions([
                        { label: 'PlayStation 4 (PS4)', value: 'PS4', emoji: '🟦' },
                        { label: 'PlayStation 5 (PS5)', value: 'PS5', emoji: '🟦' },
                        { label: 'PC (Standard / Epic / Steam)', value: 'PC', emoji: '💻' },
                        { label: 'PC Enhanced / FiveM', value: 'PC Enhanced', emoji: '⚡' }
                    ])
            );

            return await interaction.editReply({
                content: `✅ Selected Activity: **${activity}**\n\n**Step 2 — Platform**\nChoose your gaming platform:`,
                components: [platformRow]
            });
        }

        // Step 3: Piattaforma selezionata -> Apre il Modal (Senza deferUpdate)
        if (interaction.isStringSelectMenu() && interaction.customId && interaction.customId.startsWith('sup_select_platform_')) {
            const encodedActivity = interaction.customId.replace('sup_select_platform_', '');
            const activity = decodeURIComponent(encodedActivity);
            const platform = interaction.values[0];

            const modal = new ModalBuilder()
                .setCustomId(`sup_modal_${platform}_${encodeURIComponent(activity)}`)
                .setTitle('LFG Support Details');

            const detailsInput = new TextInputBuilder()
                .setCustomId('sup_details')
                .setLabel('Add specific notes (e.g. Hard mode, B2B)')
                .setPlaceholder('Type your requirements, approach, or time here...')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
                .setMaxLength(300);

            modal.addComponents(new ActionRowBuilder().addComponents(detailsInput));

            return await interaction.showModal(modal);
        }

        // Step 4: Invio del Modal -> Invia l'alert nei canali
        if (interaction.isModalSubmit() && interaction.customId && interaction.customId.startsWith('sup_modal_')) {
            const parts = interaction.customId.split('_');
            const platform = parts[2];
            const encodedActivity = parts.slice(3).join('_');
            const activity = decodeURIComponent(encodedActivity);
            const details = interaction.fields.getTextInputValue('sup_details');

            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

            const alertEmbed = new EmbedBuilder()
                .setTitle('🚨 THE SYNDICATE V — LFG & SUPPORT ALERT')
                .setDescription('A new session or assistance request has been posted by a member.')
                .setColor('#ff4757')
                .addFields(
                    { name: '👤 Requested By', value: `<@${interaction.user.id}>`, inline: false },
                    { name: '🎮 Activity / Heist', value: `\`${activity}\``, inline: true },
                    { name: '🟦 Platform', value: `\`${platform}\``, inline: true },
                    { name: '📝 Notes & Specifications', value: `\`\`\`${details}\`\`\``, inline: false }
                )
                .setImage('https://i.imgur.com/Ie4j48r.jpeg')
                .setFooter({ text: 'The Syndicate V • Staff Support & LFG Dispatcher' })
                .setTimestamp();

            const channel = await interaction.client.channels.fetch(GTA_SUPPORT_CHANNEL_ID).catch(() => null);
            if (channel) {
                await channel.send({
                    content: `📢 **LFG ALERT** | <@${interaction.user.id}> is looking for squad / help with **${activity}** on **${platform}**!`,
                    embeds: [alertEmbed]
                });
            }

            const italianChannel = await interaction.client.channels.fetch(ITALIAN_SUPPORT_CHANNEL_ID).catch(() => null);
            if (italianChannel && italianChannel.id !== GTA_SUPPORT_CHANNEL_ID) {
                await italianChannel.send({
                    content: `📢 **LFG ALERT (IT)** | <@${interaction.user.id}> cerca supporto per **${activity}** su **${platform}**!`,
                    embeds: [alertEmbed]
                }).catch(() => {});
            }

            return await interaction.editReply({
                content: '✅ **LFG Alert successfully posted!** Your request has been broadcasted to the support channel.'
            });
        }

    } catch (error) {
        console.error('❌ Support Interaction Error:', error);
        if (interaction.deferred || interaction.replied) {
            await interaction.editReply({ content: '❌ An unexpected error occurred while processing your request.' }).catch(() => {});
        } else {
            await interaction.reply({ content: '❌ An unexpected error occurred while processing your request.', flags: [MessageFlags.Ephemeral] }).catch(() => {});
        }
    }
}

module.exports = {
    ensureSupportPanel,
    handleSupportInteractions
};