const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const { addAndCheckWarning } = require('../utils/warningsManager');

const badWordsPath = path.join(__dirname, '../badwords.json');

function getBadWords() {
    try {
        if (!fs.existsSync(badWordsPath)) return [];
        const data = fs.readFileSync(badWordsPath, 'utf8');
        const json = JSON.parse(data);
        return Array.isArray(json.words) ? json.words : [];
    } catch (error) {
        return [];
    }
}

async function handleAntiBadWords(message) {
    if (!message || message.author.bot || !message.guild) return false;

    const badWords = getBadWords();
    if (badWords.length === 0) return false;

    const rawContent = message.content.toLowerCase();
    let matched = false;

    for (const word of badWords) {
        const lowerWord = word.toLowerCase();
        const regex = new RegExp(`\\b${lowerWord}\\b`, 'i');
        if (regex.test(rawContent) || rawContent.includes(lowerWord)) {
            matched = true;
            break;
        }
    }

    if (matched) {
        try {
            if (message.deletable) {
                await message.delete();
            }

            const totalWarnings = await addAndCheckWarning(message.guild, message.author, 'Used prohibited vocabulary');

            const warningEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Moderation Notice')
                .setDescription(`${message.author}, your message contained prohibited language and was removed. (Warning count: ${totalWarnings})`);

            const warningMsg = await message.channel.send({ embeds: [warningEmbed] });
            setTimeout(async () => {
                try { await warningMsg.delete(); } catch (e) {}
            }, 6000);

            console.log(`[Anti-BadWords] Deleted message from ${message.author.tag}. Total warnings: ${totalWarnings}`);
            return true;
        } catch (error) {
            console.error('Error in handleAntiBadWords:', error);
        }
    }

    return false;
}

module.exports = { handleAntiBadWords };