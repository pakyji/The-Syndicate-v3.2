const { EmbedBuilder } = require('discord.js');
const { addAndCheckWarning } = require('../utils/warningsManager');

async function handleAntiLink(message) {
    if (!message || message.author.bot || !message.guild) return false;

    const content = message.content || '';
    const linkRegex = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9][-a-zA-Z0-9]*\.(com|org|net|edu|gov|mil|io|co|me|info|biz|xyz|ly|gl|cc|tv)(\/[^\s]*)?)|(discord\.(gg|com\/invite)\/[^\s]+)/i;

    if (linkRegex.test(content)) {
        try {
            if (message.deletable) {
                await message.delete();
            }

            const totalWarnings = await addAndCheckWarning(message.guild, message.author, 'Posted prohibited link');

            const warningEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Anti-Link Protection')
                .setDescription(`${message.author}, links are strictly prohibited in this channel. (Warning count: ${totalWarnings})`);

            const warningMsg = await message.channel.send({ embeds: [warningEmbed] });
            setTimeout(async () => {
                try { await warningMsg.delete(); } catch (e) {}
            }, 6000);

            console.log(`[Anti-Link] Deleted message from ${message.author.tag}. Total warnings: ${totalWarnings}`);
            return true;
        } catch (error) {
            console.error('Error in handleAntiLink:', error);
        }
    }

    return false;
}

module.exports = { handleAntiLink };