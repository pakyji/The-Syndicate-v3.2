const { EmbedBuilder } = require('discord.js');
const { addAndCheckWarning } = require('../utils/warningsManager');

const userMessageTracker = new Map();
const SPAM_WINDOW = 6000; 
const MAX_MESSAGES = 4;   

async function handleAntiSpam(message) {
    if (!message || message.author.bot || !message.guild) return false;

    const userId = message.author.id;
    const currentTime = Date.now();

    if (!userMessageTracker.has(userId)) {
        userMessageTracker.set(userId, []);
    }

    const userTimestamps = userMessageTracker.get(userId);
    const recentMessages = userTimestamps.filter(entry => currentTime - entry.timestamp < SPAM_WINDOW);
    const duplicateCount = recentMessages.filter(entry => entry.content === message.content).length;

    recentMessages.push({ timestamp: currentTime, content: message.content });
    userMessageTracker.set(userId, recentMessages);

    if (recentMessages.length > MAX_MESSAGES || duplicateCount >= 3) {
        try {
            if (message.deletable) {
                await message.delete();
            }

            const totalWarnings = await addAndCheckWarning(message.guild, message.author, 'Spamming messages or repeating content');

            const warningEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Anti-Spam Protection')
                .setDescription(`${message.author}, please slow down. Spamming is not allowed. (Warning count: ${totalWarnings})`);

            const warningMsg = await message.channel.send({ embeds: [warningEmbed] });
            setTimeout(async () => {
                try { await warningMsg.delete(); } catch (e) {}
            }, 6000);

            userMessageTracker.set(userId, []);
            console.log(`[Anti-Spam] Triggered for ${message.author.tag}. Total warnings: ${totalWarnings}`);
            return true;
        } catch (error) {
            console.error('Error in handleAntiSpam:', error);
        }
    }

    return false;
}

module.exports = { handleAntiSpam };