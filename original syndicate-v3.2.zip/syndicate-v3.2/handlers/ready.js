// ═══════════════════════════════════════════════
//      THE SYNDICATE — READY ANNOUNCEMENT HANDLER
// ═══════════════════════════════════════════════

const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`[BOT READY] Logged in as ${client.user.tag}!`);

        const englishChannelId = '901685831943733268';
        const italianChannelId = '1537221793922940928';

        try {
            const englishChannel = await client.channels.fetch(englishChannelId).catch(() => null);
            const italianChannel = await client.channels.fetch(italianChannelId).catch(() => null);

            const row1 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('reg_pc').setLabel('🖥️ PC').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('reg_pc_enhanced').setLabel('🖥️ PC Enhanced').setStyle(ButtonStyle.Primary)
            );

            const row2 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('reg_ps4').setLabel('🎮 PS4').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('reg_ps5').setLabel('🎮 PS5').setStyle(ButtonStyle.Success)
            );

            // 1. English Announcement
            if (englishChannel) {
                const englishEmbed = new EmbedBuilder()
                    .setTitle('🎮 THE SYNDICATE — GAMER PROFILE REGISTRATION')
                    .setDescription('> Welcome to **THE SYNDICATE**\n> All existing members must register their gaming profile to maintain crew access.')
                    .setColor('#00ffcc')
                    .addFields(
                        { name: '🪪 GamerTag / PSN ID:', value: '`Not registered`', inline: false },
                        { name: '⭐ Rank:', value: '`Not registered`', inline: false },
                        { name: '🎮 Platform:', value: '`Not selected`', inline: false }
                    )
                    .setFooter({ text: 'From The Syndicate Staff Team • Built • Protected • United' })
                    .setTimestamp();

                await englishChannel.send({
                    content: '@everyone 🚨 **ATTENTION MEMBERS:** Please register your gaming profile using the buttons below!',
                    embeds: [englishEmbed],
                    components: [row1, row2]
                });
                console.log('✅ English registration announcement sent successfully!');
            }

            // 2. Italian Announcement
            if (italianChannel) {
                const italianEmbed = new EmbedBuilder()
                    .setTitle('🎮 THE SYNDICATE — REGISTRAZIONE PROFILO GAMER')
                    .setDescription('> Benvenuto in **THE SYNDICATE**\n> Tutti i membri attuali devono registrare il proprio profilo di gioco per mantenere l\'accesso.')
                    .setColor('#00ffcc')
                    .addFields(
                        { name: '🪪 GamerTag / PSN ID:', value: '`Non registrato`', inline: false },
                        { name: '⭐ Rank:', value: '`Non registrato`', inline: false },
                        { name: '🎮 Platform:', value: '`Non selezionata`', inline: false }
                    )
                    .setFooter({ text: 'From The Syndicate Staff Team • Built • Protected • United' })
                    .setTimestamp();

                await italianChannel.send({
                    content: '@everyone 🚨 **ATTENZIONE MEMBRI:** Registrate il vostro profilo di gioco usando i pulsanti sottostanti!',
                    embeds: [italianEmbed],
                    components: [row1, row2]
                });
                console.log('✅ Italian registration announcement sent successfully!');
            }

        } catch (error) {
            console.error('❌ Announcement Error:', error);
        }
    },
};