const fs = require('fs');
const path = require('path');

module.exports = (client) => {
    const commandsPath = path.join(__dirname, '../commands');

    // Recursive function to read commands from main folder and subfolders (e.g., economy)
    function readCommandFiles(dir) {
        const items = fs.readdirSync(dir, { withFileTypes: true });

        for (const item of items) {
            const fullPath = path.join(dir, item.name);

            if (item.isDirectory()) {
                // If it's a subfolder, go deeper into it
                readCommandFiles(fullPath);
            } else if (item.name.endsWith('.js')) {
                // If it's a JS file, load it
                const command = require(fullPath);

                if ('data' in command && 'execute' in command) {
                    client.commands.set(command.data.name, command);
                    console.log(`✅ Loaded Command: ${command.data.name}`);
                } else {
                    console.log(`⚠️ Warning: ${item.name} mein 'data' ya 'execute' property missing hai.`);
                }
            }
        }
    }

    readCommandFiles(commandsPath);
};